<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<!--code has try catch at the botton for verfying postal and countries-->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARRMS</title>
    <!--bootstrap for layout-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
<style>
    /*--------this is for the registration tab---------*/
.container {
    max-width: 400px;
    background-color: #ffffff;
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    margin: 50px auto;
}

legend {
    font-size: 1.5em;
    font-weight: bold;
    margin-bottom: 20px;
    color: #333;
}

.form-group {
    margin-bottom: 20px;
}

label {
    font-weight: bold;
    color: #333;
}

textarea.form-control {
    resize: vertical;
}

.btn-primary,
.btn-secondary,
.btn-danger {
    width: 100%;
    margin-top: 10px;
}

.btn-primary:hover,
.btn-secondary:hover,
.btn-danger:hover {
    opacity: 0.8;
}

.btn-danger {
    background-color: #d9534f;
    border-color: #d9534f;
}

.btn-danger:hover {
    background-color: #c9302c;
    border-color: #ac2925;
}

/* Optional: Add media queries for responsiveness 
@media (max-width: 768px) {
    .container {
        width: 90%;
    }
} */
</style>
</head>
<body>
    <!--header banner-->
    <header>
        <nav class="navbar">
            <a href="#" class="logo">ARRMS:User</a>
            <ul class="nav-links">
            <li><a href="home.php">Home</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="login.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <br>
    <br>
    <!-- Main content section -->
    <section class="main-content">
    <div class="container">
        <div class="row">
            <!-- Card for User Page -->
            <div class="column1">
                <div class="card">
                    <h2>Go to User Page</h2>
                    <p>Access your user page information</p>
                    <a href="user.php" class="btn btn-primary">Go to User Page</a>
                </div>
            </div>
            <!-- Card for Dashboard -->
            <div class="column2">
                <div class="card">
                    <h2>Go to Dashboard</h2>
                    <p>Access the dashboard</p>
                    <a href="dashboard.php" class="btn btn-primary">Go to Dashboard</a>
                </div>
            </div>
        </div>
    </div>
</section>
    <br>
<br>
<!--footer--->
<footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Recording Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
                <a href="#">Home</a>
                <a href="#">About Us</a>
                <a href="#">Login</a>
                <a href="#">Registration</a>
                <a href="#">Contact Us</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>