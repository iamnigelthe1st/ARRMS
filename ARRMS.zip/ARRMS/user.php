<?php
@session_start();

// Database configuration
$host = 'localhost';
$dbname = 'arrms';
$username = 'root';
$password = '';

// Create a PDO instance
$dsn = "mysql:host=$host;dbname=$dbname";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];
try {
    $pdo = new PDO($dsn, $username, $password, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Handle login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $_SESSION['user_id'] = $_POST['rancherId'];
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}

// Update information
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $userId = $_SESSION['user_id'];
    $params = [];
    $queryParts = [];

    if (!empty($_POST['email'])) {
        $params['newEmail'] = $_POST['email'];
        $queryParts[] = "Email = :newEmail";
    }
    if (!empty($_POST['contactNumber'])) {
        $params['newContactNumber'] = $_POST['contactNumber'];
        $queryParts[] = "ContactNumber = :newContactNumber";
    }

    if (!empty($queryParts)) {
        $updateQuery = "UPDATE Ranchers SET " . implode(', ', $queryParts) . " WHERE RancherID = :userId";
        $params['userId'] = $userId;
        $updateStmt = $pdo->prepare($updateQuery);
        $updateStmt->execute($params);
    }
}

// Fetch user information from the database
$userId = $_SESSION['user_id'] ?? null; // Assuming user_id is set in the session upon login
$user = [];
if ($userId) {
    $query = "SELECT * FROM Ranchers WHERE RancherID = :userId";
    $statement = $pdo->prepare($query);
    $statement->execute(['userId' => $userId]);
    $user = $statement->fetch();
    
}

?>

<!DOCTYPE html>
<html lang="en">
<!--code has try catch at the botton for verfying postal and countries-->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARRMS</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
<style>
    /*--------this is for the registration tab---------*/
.container {
    max-width: 400px;
    background-color: #ffffff;
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    margin: 50px auto;
}

legend {
    font-size: 1.5em;
    font-weight: bold;
    margin-bottom: 20px;
    color: #333;
}

.form-group {
    margin-bottom: 20px;
}

label {
    font-weight: bold;
    color: #333;
}

textarea.form-control {
    resize: vertical;
}

.btn-primary,
.btn-secondary,
.btn-danger {
    width: 100%;
    margin-top: 10px;
}

.btn-primary:hover,
.btn-secondary:hover,
.btn-danger:hover {
    opacity: 0.8;
}

.btn-danger {
    background-color: #d9534f;
    border-color: #d9534f;
}

.btn-danger:hover {
    background-color: #c9302c;
    border-color: #ac2925;
}

/* Optional: Add media queries for responsiveness 
@media (max-width: 768px) {
    .container {
        width: 90%;
    }
} */
</style>
</head>
<body>
    <!--header banner-->
    <header>
        <nav class="navbar">
            <a href="user.php" class="logo">ARRMS:user information</a>
            <ul class="nav-links">
                <li><a href="home.php">Home</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="login.php">Logout</a></li>
                <li><a href="main.php">Main</a></li>
            </ul>
        </nav>
    </header>
<br>
<!-- Main content section -->
<section class="main-content">
    <div class="container">
        <h2>User Details</h2>
        <?php if (!$userId): ?>
        <!-- Login Form -->
        <h2>Login</h2>
        <form method="post">
            <label for="rancherId">Enter Rancher ID:</label>
            <input type="text" id="rancherId" name="rancherId" required>
            <input type="submit" name="login" value="Login">
        </form>
        <?php else: ?>
        <!-- Display user information if logged in -->
        <h2>User Information</h2>
        <p><strong>First Name:</strong> <?php echo htmlspecialchars($user['FirstName'] ?? 'N/A'); ?></p>
        <p><strong>Last Name:</strong> <?php echo htmlspecialchars($user['LastName'] ?? 'N/A'); ?></p>
        <p><strong>Gender:</strong> <?php echo htmlspecialchars($user['Gender'] ?? 'N/A'); ?></p>
        <p><strong>Date of Birth:</strong> <?php echo htmlspecialchars($user['DateOfBirth'] ?? 'N/A'); ?></p>
        <p><strong>Contact Number:</strong> <?php echo htmlspecialchars($user['ContactNumber'] ?? 'N/A'); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($user['Email'] ?? 'N/A'); ?></p>

        <!-- Update Form -->
        <h4>Update Information</h4>
        <form method="post" id="updateForm">
    <label for="email">New Email:</label>
    <input type="email" id="email" name="email" value="">
    <label for="contactNumber">New Contact Number:</label>
    <input type="text" id="contactNumber" name="contactNumber" value="">
    <input type="submit" name="update" value="Update Information">
</form>
    <?php endif; ?>
        
</section>
<br>
<br>
<!--footer--->
<footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Recording Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
                <a href="home.php">Home</a>
                <a href="#">About Us</a>
                <a href="login.php">Login</a>
                <a href="register.php">Registration</a>
                <a href="#">Contact Us</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
<!-- JavaScript to handle form submission -->
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Add event listener to the form submission
    var updateForm = document.getElementById('updateForm'); // Ensure your form has this ID

    updateForm.addEventListener('submit', function(event) {
        event.preventDefault();
        
        // Retrieve updated user information from the form
        var email = document.getElementById('email').value;
        var contactNumber = document.getElementById('contactNumber').value;

        // Create FormData object to send form data to server
        var formData = new FormData(updateForm); // Attach the form directly
        formData.append('update', 'true'); // Make sure to append the action key or trigger

        // Send a POST request to PHP for updating user information
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '', true); // You can adjust the URL if necessary, leave blank to post to the same page
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                // Optionally process response or reload the page to reflect the changes
                console.log('Update successful');
                window.location.reload();
            }
        };
        xhr.send(formData);
    });
});
</script>


</body>
</html>