<?php
@session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $contactNumber = $_POST['contactNumber'];
    $password = $_POST['password'];

    // Check if email or contact number is provided
    if (empty($email) && empty($contactNumber)) {
        echo "Please provide your email address or contact number";
    }elseif(empty($password)){
        echo "Please provide your password";
    }
else{
    // Query for Ranchers
    $rancher_query = "SELECT * FROM Ranchers WHERE (Email = '$email' OR ContactNumber = '$contactNumber')";
    $rancher_result = $conn->query($rancher_query);

    if ($rancher_result->num_rows > 0) {
        $row = $rancher_result->fetch_assoc();

        if(password_verify($password, $row['Password'])) {
            $_SESSION['user_type'] = 'rancher';
            $_SESSION['name'] = $row['FirstName']." ".$row['LastName'];
            header("Location: main.php");
            exit;
        } else {
            echo "Invalid password"; // Return error message
        }
    } else {
        echo "User does not exist"; // Return error message
    }
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
    <style>
        fieldset{
            background-image: url('./images/login1.jpg');
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            
        }
        .login-container {
            width: 300px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-top: 50px;
            background-color: white;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        #userType {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .forgot-password-btn {
    background-color: #4caf50;
    color: white;
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    width:100%;
}

.forgot-password-btn:hover {
    background-color: #45a049;
}
</style>
<script>
    function login() {
    // Retrieve input values
    var email = document.getElementById("txtEmail").value;
    var contactNumber = document.getElementById("txtContactNumber").value;
    var password = document.getElementById("password").value;
    // Check if either email or contact number is provided
    if (!email && !contactNumber) {
        alert("Please enter your email address or contact number");
        return;
    }
    // Check if password is provided
    else if (!password) {
        alert("Please enter your password");
        return;
    }else{
    // Send a POST request to PHP for login validation
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "login.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            var response = xhr.responseText;
        
        }
    };
    // Send user credentials to PHP for validation
    xhr.send("email=" + email + "&contactNumber=" + contactNumber + "&password=" + password);
}
}
// Function to handle "Forgot Password?" button click
function forgotPassword() {
            var email = document.getElementById("txtEmail").value;
            var contactNumber = document.getElementById("txtContactNumber").value;

            // Check if either email or contact number is provided
            if (!email && !contactNumber) {
                alert("Please enter your email address or contact number to proceed with password recovery.");
                return;
            }

            window.location.href = "forgot.php"; // Redirect to forgot.php page
        }
</script>

</head>
<body>
    <header>
        <nav class="navbar">
            <a href="login.php" class="logo">ARRMS:Login</a>
            <ul class="nav-links">
                <li><a href="home.php">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
                <li><a href="home.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <br>
    <!--Content-->
    <!-- Login form -->
<form  method="POST">
    <fieldset>
        <div class="login-container">
            <h2>Login</h2>
            <!-- Email Address -->
            <div class="form-group">
                <label for="txtEmail">Email address</label>
                <input type="email" class="form-control" id="txtEmail" name="email" placeholder="Enter your email address">
            </div>
            <!-- Contact Number -->
            <div class="form-group">
                <label for="txtContactNumber">Contact Number</label>
                <input type="tel" class="form-control" id="txtContactNumber" name="contactNumber" placeholder="Enter your contact number">
            </div>
            <!-- Password section -->
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required>
            </div>
            <!-- Submit button -->
            <div class="form-group">
                <!-- <input type="submit" value="Login"> -->
                <button class="forgot-password-btn" onclick="login()">Login</button>
            </div>
            <!-- Forgot Password button -->
            <div class="form-group">
                <button class="forgot-password-btn" onclick="forgotPassword()">Forgot Password?</button>
            </div>
        </div>
    </fieldset>
</form>

    <br>
    <!--footer--->
    <footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Records Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
                <a href="#">Home</a>
                <a href="#">About Us</a>
                <a href="#">Login</a>
                <a href="#">Registration</a>
                <a href="#">Contact Us</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
    
</body>
</html>