<?php
@session_start();
// Check if admin is logged in
if (!isset($_SESSION['admin_username'])) {
    header("Location: adminlogin.html");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// CRUD operations for ranchers (users)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['create'])) {
        // Handle create operation
        // Example: create rancher (user) account
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        $gender = $_POST['gender'];
        $dateOfBirth = $_POST['dateOfBirth'];
        $contactNumber = $_POST['contactNumber'];
        $email = $_POST['email'];
        $country = $_POST['country'];
        $postalAddress = $_POST['postalAddress'];
        // Add validation and insertion code here
    } elseif (isset($_POST['update'])) {
        // Handle update operation
        // Example: update rancher (user) account
        $rancherID = $_POST['rancherID'];
        $firstName = $_POST['firstName'];
        $lastName = $_POST['lastName'];
        $gender = $_POST['gender'];
        $dateOfBirth = $_POST['dateOfBirth'];
        $contactNumber = $_POST['contactNumber'];
        $email = $_POST['email'];
        $country = $_POST['country'];
        $postalAddress = $_POST['postalAddress'];
        // Add validation and update code here
    } elseif (isset($_POST['delete'])) {
        // Handle delete operation
        // Example: delete rancher (user) account
        $rancherID = $_POST['rancherID'];
        // Add deletion code here
    }
}

// Fetch ranchers (users) from database
$sql = "SELECT * FROM Ranchers";
$result = $conn->query($sql);

$ranchers = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $ranchers[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Accounts</title>
    <style>
        /* CSS for user accounts page */
.container {
    max-width: 800px;
    margin: 0 auto;
}

h2, h3 {
    text-align: center;
}

form {
    margin-bottom: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table, th, td {
    border: 1px solid black;
}

th, td {
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

    </style>
</head>
<body>
    <h2>User Accounts</h2>
    <div class="container">
        <h3>Create User Account</h3>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="firstName">First Name:</label>
            <input type="text" name="firstName" required><br><br>
            <label for="lastName">Last Name:</label>
            <input type="text" name="lastName" required><br><br>
            <label for="gender">Gender:</label>
            <select name="gender">
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
            </select><br><br>
            <label for="dateOfBirth">Date of Birth:</label>
            <input type="date" name="dateOfBirth" required><br><br>
            <label for="contactNumber">Contact Number:</label>
            <input type="text" name="contactNumber"><br><br>
            <label for="email">Email:</label>
            <input type="email" name="email" required><br><br>
            <label for="country">Country:</label>
            <input type="text" name="country"><br><br>
            <label for="postalAddress">Postal Address:</label>
            <input type="text" name="postalAddress"><br><br>
            <input type="submit" name="create" value="Create">
        </form>

        <h3>User Accounts List</h3>
        <table>
            <tr>
                <th>Rancher ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Gender</th>
                <th>Date of Birth</th>
                <th>Contact Number</th>
                <th>Email</th>
                <th>Country</th>
                <th>Postal Address</th>
                <th>Action</th>
            </tr>
            <?php foreach ($ranchers as $rancher): ?>
                <tr>
                    <td><?php echo $rancher['RancherID']; ?></td>
                    <td><?php echo $rancher['FirstName']; ?></td>
                    <td><?php echo $rancher['LastName']; ?></td>
                    <td><?php echo $rancher['Gender']; ?></td>
                    <td><?php echo $rancher['DateOfBirth']; ?></td>
                    <td><?php echo $rancher['ContactNumber']; ?></td>
                    <td><?php echo $rancher['Email']; ?></td>
                    <td><?php echo $rancher['Country']; ?></td>
                    <td><?php echo $rancher['PostalAddress']; ?></td>
                    <td>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <input type="hidden" name="rancherID" value="<?php echo $rancher['RancherID']; ?>">
                            <input type="submit" name="update" value="Update">
                            <input type="submit" name="delete" value="Delete" onclick="return confirm('Are you sure you want to delete this rancher?')">
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <script>
        function validateForm(event) {
            event.preventDefault(); // Prevent form submission

            // Get form fields
            var firstName = document.forms["createUserForm"]["firstName"].value;
            var lastName = document.forms["createUserForm"]["lastName"].value;
            var dateOfBirth = document.forms["createUserForm"]["dateOfBirth"].value;
            var email = document.forms["createUserForm"]["email"].value;

            // Simple validation example (add more as needed)
            if (firstName === "" || lastName === "" || dateOfBirth === "" || email === "") {
                alert("All fields are required");
                return false; // Prevent form submission
            }

            // If validation passes, the form will be submitted
            document.getElementById("createUserForm").submit();
        }
    </script>
</body>
</html>
