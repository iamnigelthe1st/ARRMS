<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (!empty($_POST)){

// Optionally set character set to utf8 (if you're dealing with non-English characters)
$conn->set_charset("utf8");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get form data 
    $animalID = $_POST['animalID'];
    $dateOfVisit = $_POST['dateOfVisit'];
    $veterinarian = $_POST['veterinarian'];
    $diagnosis = $_POST['diagnosis'];
    $treatment = $_POST['treatment'];
    $prescription = $_POST['prescription'];
    $cost = $_POST['cost'];

//     $stmt = $conn->prepare("INSERT INTO Admin (Username, PASSWORD, FirstName, LastName, Email) VALUES (?, ?, ?, ?, ?)");
// if ($stmt->execute([$username, $password, $firstName, $lastName, $email])) {
    // Parent1ID`, `Parent2ID`, `DateOfBreeding`, `NumberOfOffspring`, `BreedingLocation`, `Notes`

    // Insert data into breedingrecords table
    
    $sql = "INSERT INTO `medicalrecords`(`AnimalID`, `DateOfVisit`, `Veterinarian`, `Diagnosis`, `Treatment`, `Prescription`, `Cost`) VALUES(?, ?, ?, ?, ?, ?, ?)";
    if ($stmt = $conn->prepare($sql)) {
        // $stmt->bind_param("isss", $animalName, $animalDOB, $animalGender);
        if ($stmt->execute([$animalID, $dateOfVisit, $veterinarian, $diagnosis, $treatment, $prescription, $cost])) {
            echo "Feeding Schedule added successfully!</br><a href='http://localhost/ARRMS/ARRMS/ARRMS/admin/admindashboard.php'>Back to dashboard</a>";
            header('Location: http://localhost/ARRMS/ARRMS/ARRMS/admin/admindashboard.php');
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        $stmt->close();
    }
    $conn->close();
}
}