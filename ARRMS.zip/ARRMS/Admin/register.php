<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if (!empty($_POST))
{

// Retrieve form data
$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$email = $_POST['email'];

// Check if username already exists
$stmt = $conn->prepare("SELECT * FROM Admin WHERE Username = ?");
$stmt->execute([$username]);
if ($stmt->fetch()) {
    $message="Username already exists. Please choose a different one.";
    exit();
}
else{


// Insert new admin into the database
$stmt = $conn->prepare("INSERT INTO Admin (Username, PASSWORD, FirstName, LastName, Email) VALUES (?, ?, ?, ?, ?)");
if ($stmt->execute([$username, $password, $firstName, $lastName, $email])) {
    // Redirect to admin login page
    print_r("<a href='http://localhost/ARRMS/ARRMS/ARRMS/admin/adminlogin.php'>proceed to login</a>");
    // $target = "http://localhost/ARRMS/ARRMS/ARRMS/admin/adminlogin.php";
    // header("Location: $target");

    // echo '<script type="text/javascript">';
    // echo 'window.location.href="";';
    // echo '</script>';


    exit();
} else {
    $message= "Error occurred. Please try again.";
}
}

}

