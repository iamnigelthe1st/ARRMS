<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(!empty($_GET)){
    $id=$_GET['id'];
    //fetch details from database
    $query="SELECT * FROM animals where AnimalID=".$id;
    $result=mysqli_query($conn, $query);
    $c=mysqli_fetch_assoc($result);
}
if(!empty($_POST)){
    $animalName = $_POST['animalName'];
    $animalDOB = $_POST['animalDOB'];
    $animalGender = $_POST['animalGender'];
    $animalID = $_POST['animalID'];

    //update animal row
    $sql = "UPDATE `animals` SET 
    `NAME`='$animalName',
    `DateOfBirth`='$animalDOB',
    `Gender`='$animalGender' WHERE `AnimalID`='$animalID'"; 
    if(mysqli_query($conn,$sql)){
        print_r('<a href="http://localhost/ARRMS/ARRMS/ARRMS/admin/admindashboard.php">Update Successful, return to dashboard</a>');
        $query="SELECT * FROM animals where AnimalID=".$animalID;
        $result=mysqli_query($conn, $query);
        $c=mysqli_fetch_assoc($result);
    }else{
        print_r("Something went wrong");
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
    <style>
        section {
            margin: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        form {
            margin-top: 20px;
        }

        label, input {
            display: block;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <fieldset>
    <section>
        <h2>Add Animal</h2>
        <form id="addAnimalForm" method="post" action="updateAnimals.php">
        <input type="text" id="animalID" name="animalID" value="<?php print_r($c['AnimalID'])?>" readonly>
            <label for="animalName">Name:</label>
            <input type="text" id="animalName" name="animalName" value="<?php print_r($c['NAME'])?>" required>

            <label for="animalDOB">Date of Birth:</label>
            <input type="date" id="animalDOB" name="animalDOB" value="<?php print_r($c['DateOfBirth'])?>" required>

            <label for="animalGender">Gender:</label>
            <select id="animalGender" name="animalGender" value="<?php print_r($c['Gender'])?>" required>
                <?php
                    if($c['Gender'] == "Male"){
                        print_r('<option value="Male" selected >Male</option><option value="Female">Female</option>');
                    }else{
                        print_r('<option value="Male"  >Male</option><option value="Female" selected>Female</option>');
                    } 
                ?>
                
                
            </select>

            <button type="submit">Update Animal</button>
        </form>
    </section>
    </fieldset>
    <br>
    <br>
    <!--footer--->
    <footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Records Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
                <a href="#">Home</a>
                <a href="#">About Us</a>
                <a href="#">Login</a>
                <a href="#">Registration</a>
                <a href="#">Contact Us</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
    
</body>
</html>