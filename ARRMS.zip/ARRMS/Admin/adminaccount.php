<?php
session_start();

$servername = "localhost";
$username = "username";
$password = ""; 
$database = "arrms"; 

// Step 2: Create a connection to the database
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 2: Create a connection to the database
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 3: Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $adminID = mysqli_real_escape_string($conn, $_POST['AdminID']);
    $email = mysqli_real_escape_string($conn, $_POST['Email']);
    $username = mysqli_real_escape_string($conn, $_POST['Username']);
    $password = mysqli_real_escape_string($conn, $_POST['Password']);

    // Step 4: Prepare and execute SQL query to update admin details
    $sql = "UPDATE Admin SET Email='$email', Username='$username', Password='$password' WHERE AdminID='$adminID'";

    if ($conn->query($sql) === TRUE) {
        // Display success message
        echo "Admin details updated successfully";
        
        // Fetch updated admin details
        $sql_fetch = "SELECT * FROM Admin WHERE AdminID = $adminID";
        $result = $conn->query($sql_fetch);
        
        if ($result->num_rows > 0) {
            // Display updated admin details
            $row = $result->fetch_assoc();
            $email = $row['Email'];
            $username = $row['Username'];
            $password = $row['Password'];
            
            echo "<h2>Updated Admin Details</h2>";
            echo "<p><strong>Email:</strong> $email</p>";
            echo "<p><strong>Username:</strong> $username</p>";
            echo "<p><strong>Password:</strong> $password</p>";
        }
    } else {
        echo "Error updating admin details: " . $conn->error;
    }
}
// Step 5: Close database connection
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Update Admin Details</title>
</head>
<body>

<h2>Update Admin Details</h2>
<form id="updateForm">
    <input type="hidden" id="AdminID" name="AdminID" value="1"> 
    <label>Email:</label>
    <input type="text" id="Email" name="Email" value=""><br><br>
    <label>Username:</label>
    <input type="text" id="Username" name="Username" value=""><br><br>
    <label>Password:</label>
    <input type="password" id="Password" name="Password" value=""><br><br>
    <input type="button" onclick="updateAdminDetails()" value="Update Details">
</form>

<div id="response"></div>

<script>
function updateAdminDetails() {
    var formData = new FormData(document.getElementById("updateForm"));
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("response").innerHTML = this.responseText;
        }
    };
    xhttp.open("POST", "update_admin.php", true);
    xhttp.send(formData);
}
</script>
</body>
</html>

