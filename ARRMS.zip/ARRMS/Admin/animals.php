<?php
@session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (!empty($_POST)){

// Optionally set character set to utf8 (if you're dealing with non-English characters)
$conn->set_charset("utf8");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $animalName = $_POST['animalName'];
    $animalDOB = $_POST['animalDOB'];
    $animalGender = $_POST['animalGender'];

//     $stmt = $conn->prepare("INSERT INTO Admin (Username, PASSWORD, FirstName, LastName, Email) VALUES (?, ?, ?, ?, ?)");
// if ($stmt->execute([$username, $password, $firstName, $lastName, $email])) {

    // Insert data into Animals table
    $sql = "INSERT INTO Animals (NAME, DateOfBirth, Gender) VALUES (?, ?, ?)";
    if ($stmt = $conn->prepare($sql)) {
        // $stmt->bind_param("isss", $animalName, $animalDOB, $animalGender);
        if ($stmt->execute([$animalName, $animalDOB, $animalGender])) {
            // echo "Animal added successfully!</br><a href='http://localhost/ARRMS/ARRMS/ARRMS/admin/admindashboard.php'>Back to dashboard</a>";
            header('Location: http://localhost/ARRMS/ARRMS/ARRMS/admin/admindashboard.php');
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        $stmt->close();
    }
    $conn->close();
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hide Hyperlinks with Text</title>
    <style>
        a {
            display: none;
        }
    </style>
</head>
<body>
</body>
</html>
