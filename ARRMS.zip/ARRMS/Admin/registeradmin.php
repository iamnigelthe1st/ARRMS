<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!empty($_POST))
{

// Retrieve form data
$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$email = $_POST['email'];

// Check if username already exists
$stmt = $conn->prepare("SELECT * FROM Admin WHERE Username = ?");
$stmt->execute([$username]);
if ($stmt->fetch()) {
    echo "Username already exists. Please choose a different one.";
    // exit();
}
else{


// Insert new admin into the database
$stmt = $conn->prepare("INSERT INTO Admin (Username, PASSWORD, FirstName, LastName, Email) VALUES (?, ?, ?, ?, ?)");
if ($stmt->execute([$username, $password, $firstName, $lastName, $email])) {
    // Redirect to admin login page
    print_r("<script>console.log('proceed to login')</script>");
    // header("Location: adminlogin.php");

    // exit();
} else {
    echo "Error occurred. Please try again.";
}
}

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration</title>
    <style>
        .container {
    max-width: 400px;
    margin: 100px auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    margin-bottom: 5px;
}

input[type="text"],
input[type="password"] {
    width: 100%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

button {
    padding: 10px 20px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Registration</h2>
        <form id="registrationForm" method="post" action="'register.php'" >
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="firstName">First Name:</label>
                <input type="text" id="firstName" name="firstName" required>
            </div>
            <div class="form-group">
                <label for="lastName">Last Name:</label>
                <input type="text" id="lastName" name="lastName" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="text" id="email" name="email" >
            </div>
            <button type="submit">Register</button>
        </form>
        <div id="message"></div>
    </div>

    <script>
        document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // prevent form submission

    var formData = new FormData(this);

    // Send form data to server for registration
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'register.php', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            document.getElementById('message').innerHTML = xhr.responseText;
        }
    };
    xhr.send(formData);
});

    </script>
</body>
</html>
