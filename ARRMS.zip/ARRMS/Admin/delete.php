<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(!empty($_GET)){
    $table=$_GET['table'];
    $id=$_GET['id'];
    $query="";
    if($table=="animal"){
        $query = "DELETE FROM `animals` WHERE AnimalID=$id";
    }elseif($table=="breeding"){
        $query = "DELETE FROM `breedingrecords` WHERE BreedingID=$id";
    }elseif($table=="feeding"){
        $query = "DELETE FROM `feedingschedule` WHERE ScheduleID=$id";
    }elseif($table=="finance"){
        $query = "DELETE FROM `salestransfers` WHERE TransactionID=$id";
    }elseif($table=="medical"){
        $query = "DELETE FROM `medicalrecords` WHERE RecordID=$id";
    }
    if($query!==""){
        $result=mysqli_query( $conn,$query );  //run the query
        if($result){
            print_r('<a href="http://localhost/ARRMS/ARRMS/ARRMS/admin/admindashboard.php">Delete Successful, back to dashboard</a>');
        }
    }else{
        print_r('<a href="http://localhost/ARRMS/ARRMS/ARRMS/admin/admindashboard.php">Back to dashboard</a>');
    }

} 
?>