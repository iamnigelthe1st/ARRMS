<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(!empty($_GET)){
    $id=$_GET['id'];
    //fetch details from database
    // breedingrecords (Parent1ID, Parent2ID, DateOfBreeding, NumberOfOffspring, BreedingLocation,Notes )
    $query="SELECT * FROM breedingrecords where BreedingID=".$id;
    $result=mysqli_query($conn, $query);
    $c=mysqli_fetch_assoc($result);
}
if(!empty($_POST)){
    $parent1ID = $_POST['parent1ID'];
        $parent2ID = $_POST['parent2ID'];
        $dateOfBreeding = $_POST['dateOfBreeding'];
        $numberOfOffspring = $_POST['numberOfOffspring'];
        $breedingLocation = $_POST['breedingLocation'];
        $notes = $_POST['notes'];
        $breedingID=$_POST['BreedingID'];

    //update animal row
    $sql = "UPDATE `breedingrecords` SET 
    `Parent1ID`='$parent1ID',
    `Parent2ID`='$parent2ID',
    `DateOfBreeding`='$dateOfBreeding', 
    `NumberOfOffspring`='$numberOfOffspring', 
    `BreedingLocation`='$breedingLocation',
    `Notes`='$notes' WHERE `BreedingID`='$breedingID'"; 
    if(mysqli_query($conn,$sql)){
        print_r('<a href="http://localhost/ARRMS/ARRMS/ARRMS/admin/admindashboard.php">Update Successful, return to dashboard</a>');
        $query="SELECT * FROM breedingrecords where BreedingID=".$breedingID;
        $result=mysqli_query($conn, $query);
        $c=mysqli_fetch_assoc($result);
    }else{
        print_r("Something went wrong");
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
    <style>
        section {
            margin: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        form {
            margin-top: 20px;
        }

        label, input {
            display: block;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    
   
    <fieldset>
    <section>
        <h2>Add Breeding Record</h2>
        <form id="addBreedingRecordForm" method="POST" action="updateBreeding.php">
        <input type="text" id="BreedingID" name="BreedingID" value="<?php print_r($c['BreedingID'])?>" readonly>
            <label for="parent1ID">Parent 1 ID:</label>
            <input type="number" id="parent1ID" name="parent1ID" value="<?php print_r($c['Parent1ID'])?>" required>

            <label for="parent2ID">Parent 2 ID:</label>
            <input type="number" id="parent2ID" name="parent2ID" value="<?php print_r($c['Parent2ID'])?>" required>

            <label for="dateOfBreeding">Date of Breeding:</label>
            <input type="date" id="dateOfBreeding" name="dateOfBreeding" value="<?php print_r($c['DateOfBreeding'])?>" required>

            <label for="numberOfOffspring">Number of Offspring:</label>
            <input type="number" id="numberOfOffspring" name="numberOfOffspring" value="<?php print_r($c['NumberOfOffspring'])?>" required>

            <label for="breedingLocation">Breeding Location:</label>
            <input type="text" id="breedingLocation" name="breedingLocation" value="<?php print_r($c['BreedingLocation'])?>" required>

            <label for="notes">Notes:</label>
            <textarea id="notes" name="notes" rows="4"><?php print_r($c['Notes'])?></textarea>

            <button type="submit">Update Breeding Record</button>
        </form>
    </section>

    
    </fieldset>
    <br>
    <br>
    <!--footer--->
    <footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Records Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
                <a href="#">Home</a>
                <a href="#">About Us</a>
                <a href="#">Login</a>
                <a href="#">Registration</a>
                <a href="#">Contact Us</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
    
</body>

</html>