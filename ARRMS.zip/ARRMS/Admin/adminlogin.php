<?php
@session_start();
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!empty($_POST))
{

// Retrieve form data
$username = $_POST['username'];
$password = $_POST['password'];

// Query database to check if user exists
$stmt = $conn->prepare("SELECT * FROM Admin WHERE Username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (password_verify($password, $user['Password'])) {
    // User authenticated, redirect to dashboard or perform desired actions
    $_SESSION['user_type'] = "admin";
    print_r("<a href='http://localhost/ARRMS/ARRMS/ARRMS/admin/admindashboard.php'>Proceed to Dashboard</a>");
    // header("Location: admindashboard.php");
    exit();
} else {
    // Authentication failed
    echo "Invalid username or password--".$password."--".password_verify($password, $user['Password']);
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        .container {
    max-width: 400px;
    margin: 100px auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    margin-bottom: 5px;
}

input[type="text"],
input[type="password"] {
    width: 100%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

button {
    padding: 10px 20px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Login</h2>
        <form id="loginForm" method="post" >
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Login</button>
            <br>
            <p> or </p>
            <a href="registeradmin.php">Register</a>
        </form>
        <div id="message"></div>
    </div>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // prevent form submission

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // Send username and password to server for validation
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'adminlogin.php', true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            document.getElementById('message').innerHTML = xhr.responseText;
        }
    };
    xhr.send('username=' + username + '&password=' + password);
});

    </script>
</body>
</html>
