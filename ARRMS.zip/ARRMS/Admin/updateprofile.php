<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_username'])) {
    header("Location: adminlogin.html");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch admin details
$adminID = $_SESSION['admin_id'];
$sql = "SELECT * FROM Admin WHERE AdminID = $adminID";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $admin = $result->fetch_assoc();
} else {
    echo "Admin not found.";
    exit();
}

// Update admin details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];

    // Perform validation here if needed
    $errors = array();

    // Check if first name is empty or contains only white spaces
    if (empty($firstName) || !preg_match("/^[a-zA-Z'-]+$/", $firstName)) {
        $errors[] = "First name is required and must contain only letters, apostrophes, and dashes.";
    }

    // Check if last name is empty or contains only white spaces
    if (empty($lastName) || !preg_match("/^[a-zA-Z'-]+$/", $lastName)) {
        $errors[] = "Last name is required and must contain only letters, apostrophes, and dashes.";
    }

    // Check if email is empty or not in valid format
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email is required and must be in valid format.";
    }

    // If there are errors, display them and prevent updating profile
    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo $error . "<br>";
        }
        exit();
    }
    
    // Update admin details in database
    $sql = "UPDATE Admin SET FirstName = '$firstName', LastName = '$lastName', Email = '$email' WHERE AdminID = $adminID";
    if ($conn->query($sql) === TRUE) {
        // Update session data
        $_SESSION['admin_firstname'] = $firstName;
        $_SESSION['admin_lastname'] = $lastName;
        $_SESSION['admin_email'] = $email;

        echo "Profile updated successfully.";
    } else {
        echo "Error updating profile: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Update Profile</title>
    <style>
        .container {
    max-width: 400px;
    margin: 50px auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

form {
    display: grid;
    gap: 10px;
}

input[type="text"],
input[type="email"] {
    width: 100%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

    </style>
</head>
<body>
    <h2>Update Profile</h2>
    <div class="container">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" onsubmit="return validateForm()">
            <label for="firstName">First Name:</label>
            <input type="text" id="firstName" name="firstName" value="<?php echo $admin['FirstName']; ?>" required><br><br>
            <label for="lastName">Last Name:</label>
            <input type="text" id="lastName" name="lastName" value="<?php echo $admin['LastName']; ?>" required><br><br>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $admin['Email']; ?>" required><br><br>
            <input type="submit" value="Update Profile">
        </form>
    </div>
    <script>
        function validateForm() {
    var firstName = document.getElementById('firstName').value;
    var lastName = document.getElementById('lastName').value;
    var email = document.getElementById('email').value;

    if (firstName.trim() === '' || lastName.trim() === '' || email.trim() === '') {
        alert('All fields are required.');
        return false;
    }

    return true;
}
    </script>
</body>
</html>
