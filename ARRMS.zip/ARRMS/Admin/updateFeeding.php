<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$id="";
if(!empty($_GET)){
    $id=$_GET['id'];
    //fetch details from database
    // breedingrecords (Parent1ID, Parent2ID, DateOfBreeding, NumberOfOffspring, BreedingLocation,Notes )
    $query="SELECT * FROM FeedingSchedule where ScheduleID=".$id;
    $result=mysqli_query($conn, $query);
    $c=mysqli_fetch_assoc($result);
}
if(!empty($_POST)){
    $animalID = $_POST['animalID'];
    $feedTime = $_POST['feedTime'];
    $feedType = $_POST['feedType'];
    $quantity = $_POST['quantity'];
    $location = $_POST['location'];
    $id = $_POST['ScheduleID'];

    //update animal row
    $sql = "UPDATE `FeedingSchedule` SET 
    `AnimalID`='$animalID',
    `FeedTime`='$feedTime',
    `FeedType`='$feedType', 
    `Quantity`='$quantity', 
    `Location`='$location' WHERE `ScheduleID`='$id'"; 
    if(mysqli_query($conn,$sql)){
        print_r('<a href="http://localhost/ARRMS/ARRMS/ARRMS/admin/admindashboard.php">Update Successful, return to dashboard</a>');
        $query="SELECT * FROM FeedingSchedule where ScheduleID=".$id;
        $result=mysqli_query($conn, $query);
        $c=mysqli_fetch_assoc($result);
    }else{
        print_r("Something went wrong");
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
    <style>
        section {
            margin: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        form {
            margin-top: 20px;
        }

        label, input {
            display: block;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    
   
    <fieldset>
    <section>

        <h2>Update Feeding Record</h2>
        <form id="addBreedingRecordForm" method="POST" action="updateFeeding.php">
        <input type="text" id="ScheduleID" name="ScheduleID" value="<?php print_r($c['ScheduleID'])?>" readonly>
        <label for="animalID">Animal ID:</label>
            <input type="number" id="animalID" name="animalID" value="<?php print_r($c['AnimalID'])?>" required>

            <label for="feedTime">Feed Time:</label>
            <input type="time" id="feedTime" name="feedTime" value="<?php print_r($c['FeedTime'])?>" required>

            <label for="feedType">Feed Type:</label>
            <input type="text" id="feedType" name="feedType" value="<?php print_r($c['FeedType'])?>" required>

            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" value="<?php print_r($c['Quantity'])?>" step="0.01" required>

            <label for="location">Location:</label>
            <input type="text" id="location" name="location" value="<?php print_r($c['Location'])?>" required>

            

            <button type="submit">Update Breeding Record</button>
        </form>
    </section>

    
    </fieldset>
    <br>
    <br>
    <!--footer--->
    <footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Records Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
                <a href="#">Home</a>
                <a href="#">About Us</a>
                <a href="#">Login</a>
                <a href="#">Registration</a>
                <a href="#">Contact Us</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
    
</body>

</html>