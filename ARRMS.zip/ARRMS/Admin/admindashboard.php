<?php
session_start();
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// CRUD operations for managing animals
// Create new animal
function createAnimal($typeID, $name, $dateOfBirth, $gender, $color, $weight, $birthplace) {
    global $pdo;

    // Basic input validation
    if (empty($typeID) || empty($name) || empty($dateOfBirth) || empty($gender) || empty($color) || empty($weight) || empty($birthplace)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO Animals (TypeID, NAME, DateOfBirth, Gender, Color, Weight, Birthplace) VALUES (?, ?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$typeID, $name, $dateOfBirth, $gender, $color, $weight, $birthplace]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}

// Read all animals
function getAllAnimals() {
    global $pdo;

    try {
        $stmt = $pdo->query("SELECT * FROM Animals");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Handle database errors
        return [];
    }
}

// Update animal
function updateAnimal($animalID, $typeID, $name, $dateOfBirth, $gender, $color, $weight, $birthplace) {
    global $pdo;

    // Basic input validation
    if (empty($animalID) || empty($typeID) || empty($name) || empty($dateOfBirth) || empty($gender) || empty($color) || empty($weight) || empty($birthplace)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("UPDATE Animals SET TypeID=?, NAME=?, DateOfBirth=?, Gender=?, Color=?, Weight=?, Birthplace=? WHERE AnimalID=?");
        return $stmt->execute([$typeID, $name, $dateOfBirth, $gender, $color, $weight, $birthplace, $animalID]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}

// Delete animal
function deleteAnimal($animalID) {
    global $pdo;

    // Basic input validation
    if (empty($animalID)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM Animals WHERE AnimalID=?");
        return $stmt->execute([$animalID]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}
// CRUD operations for managing breeding records
// Create new breeding record
function createBreedingRecord($parent1ID, $parent2ID, $dateOfBreeding, $numberOfOffspring, $breedingLocation, $notes) {
    global $pdo;

    // Basic input validation
    if (empty($parent1ID) || empty($parent2ID) || empty($dateOfBreeding) || empty($numberOfOffspring) || empty($breedingLocation)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO BreedingRecords (Parent1ID, Parent2ID, DateOfBreeding, NumberOfOffspring, BreedingLocation, Notes) VALUES (?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$parent1ID, $parent2ID, $dateOfBreeding, $numberOfOffspring, $breedingLocation, $notes]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}
// Read all breeding records
function getAllBreedingRecords() {
    global $pdo;

    try {
        $stmt = $pdo->query("SELECT * FROM BreedingRecords");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Handle database errors
        return [];
    }
}
// Update breeding record
function updateBreedingRecord($breedingID, $parent1ID, $parent2ID, $dateOfBreeding, $numberOfOffspring, $breedingLocation, $notes) {
    global $pdo;

    // Basic input validation
    if (empty($breedingID) || empty($parent1ID) || empty($parent2ID) || empty($dateOfBreeding) || empty($numberOfOffspring) || empty($breedingLocation)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("UPDATE BreedingRecords SET Parent1ID=?, Parent2ID=?, DateOfBreeding=?, NumberOfOffspring=?, BreedingLocation=?, Notes=? WHERE BreedingID=?");
        return $stmt->execute([$parent1ID, $parent2ID, $dateOfBreeding, $numberOfOffspring, $breedingLocation, $notes, $breedingID]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}
// Delete breeding record
function deleteBreedingRecord($breedingID) {
    global $pdo;

    // Basic input validation
    if (empty($breedingID)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM BreedingRecords WHERE BreedingID=?");
        return $stmt->execute([$breedingID]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}

// CRUD operations for managing feeding schedules
// Create new feeding schedule
function createFeedingSchedule($animalID, $feedTime, $feedType, $quantity, $location) {
    global $pdo;

    // Basic input validation
    if (empty($animalID) || empty($feedTime) || empty($feedType) || empty($quantity) || empty($location)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO FeedingSchedule (AnimalID, FeedTime, FeedType, Quantity, Location) VALUES (?, ?, ?, ?, ?)");
        return $stmt->execute([$animalID, $feedTime, $feedType, $quantity, $location]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}
// Read all feeding schedules
function getAllFeedingSchedules() {
    global $pdo;

    try {
        $stmt = $pdo->query("SELECT * FROM FeedingSchedule");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Handle database errors
        return [];
    }
}
// Update feeding schedule
function updateFeedingSchedule($scheduleID, $feedTime, $feedType, $quantity, $location) {
    global $pdo;

    // Basic input validation
    if (empty($scheduleID) || empty($feedTime) || empty($feedType) || empty($quantity) || empty($location)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("UPDATE FeedingSchedule SET FeedTime=?, FeedType=?, Quantity=?, Location=? WHERE ScheduleID=?");
        return $stmt->execute([$feedTime, $feedType, $quantity, $location, $scheduleID]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}
// Delete feeding schedule
function deleteFeedingSchedule($scheduleID) {
    global $pdo;

    // Basic input validation
    if (empty($scheduleID)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM FeedingSchedule WHERE ScheduleID=?");
        return $stmt->execute([$scheduleID]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}

// CRUD operations for managing finance records
// Create new finance record
function createFinanceRecord($animalID, $transactionDate, $transactionType, $amount, $buyerSellerName, $transactionNotes) {
    global $pdo;

    // Basic input validation
    if (empty($animalID) || empty($transactionDate) || empty($transactionType) || empty($amount) || empty($buyerSellerName)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO SalesTransfers (AnimalID, TransactionDate, TransactionType, Amount, BuyerSellerName, TransactionNotes) VALUES (?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$animalID, $transactionDate, $transactionType, $amount, $buyerSellerName, $transactionNotes]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}
// Read all finance records
function getAllFinanceRecords() {
    global $pdo;

    try {
        $stmt = $pdo->query("SELECT * FROM SalesTransfers");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Handle database errors
        return [];
    }
}
// Update finance record
function updateFinanceRecord($transactionID, $transactionDate, $transactionType, $amount, $buyerSellerName, $transactionNotes) {
    global $pdo;

    // Basic input validation
    if (empty($transactionID) || empty($transactionDate) || empty($transactionType) || empty($amount) || empty($buyerSellerName)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("UPDATE SalesTransfers SET TransactionDate=?, TransactionType=?, Amount=?, BuyerSellerName=?, TransactionNotes=? WHERE TransactionID=?");
        return $stmt->execute([$transactionDate, $transactionType, $amount, $buyerSellerName, $transactionNotes, $transactionID]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}
// Delete finance record
function deleteFinanceRecord($transactionID) {
    global $pdo;

    // Basic input validation
    if (empty($transactionID)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM SalesTransfers WHERE TransactionID=?");
        return $stmt->execute([$transactionID]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}

// CRUD operations for managing medical records
// Create new medical record
function createMedicalRecord($animalID, $dateOfVisit, $veterinarian, $diagnosis, $treatment, $prescription, $cost) {
    global $pdo;

    // Basic input validation
    if (empty($animalID) || empty($dateOfVisit) || empty($veterinarian) || empty($diagnosis) || empty($treatment) || empty($prescription) || empty($cost)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO MedicalRecords (AnimalID, DateOfVisit, Veterinarian, Diagnosis, Treatment, Prescription, Cost) VALUES (?, ?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$animalID, $dateOfVisit, $veterinarian, $diagnosis, $treatment, $prescription, $cost]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}

// Read all medical records
function getAllMedicalRecords() {
    global $pdo;

    try {
        $stmt = $pdo->query("SELECT * FROM MedicalRecords");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        // Handle database errors
        return [];
    }
}

// Update medical record
function updateMedicalRecord($recordID, $dateOfVisit, $veterinarian, $diagnosis, $treatment, $prescription, $cost) {
    global $pdo;

    // Basic input validation
    if (empty($recordID) || empty($dateOfVisit) || empty($veterinarian) || empty($diagnosis) || empty($treatment) || empty($prescription) || empty($cost)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("UPDATE MedicalRecords SET DateOfVisit=?, Veterinarian=?, Diagnosis=?, Treatment=?, Prescription=?, Cost=? WHERE RecordID=?");
        return $stmt->execute([$dateOfVisit, $veterinarian, $diagnosis, $treatment, $prescription, $cost, $recordID]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}

// Delete medical record
function deleteMedicalRecord($recordID) {
    global $pdo;

    // Basic input validation
    if (empty($recordID)) {
        return false; // Validation failed
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM MedicalRecords WHERE RecordID=?");
        return $stmt->execute([$recordID]);
    } catch (PDOException $e) {
        // Handle database errors
        return false;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        .navbar {
            background-color: #333;
            overflow: hidden;
        }
        .nav-links {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            justify-content: flex-start;
        }
        .nav-links li {
            margin: 0;
        }
        .nav-links a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
        }
        .nav-links a:hover {
            background-color: #575757;
        }
        .container {
            padding: 20px;
        }
        h1 {
            text-align: center;
        }
        .section {
            background: white;
            margin-bottom: 20px;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .section h2 {
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .form-control {
            margin-bottom: 15px;
        }
        .form-control label {
            display: block;
            margin-bottom: 5px;
        }
        .form-control input, .form-control textarea {
            width: calc(100% - 20px);
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-control button {
            background-color: #333;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-control button:hover {
            background-color: #575757;
        }
        /*-------------footer-------------*/
footer {
    background: #917e18;
    color: #fff;
    text-align: center;
    padding: 20px 0;
}

.footer-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 20px;
}

.footer-content h3 {
    font-size: 1.2rem;
    font-weight: 400;
    text-transform: capitalize;
    line-height: 1.5rem;
    margin-bottom: 5px;
}

.footer-content p {
    max-width: 500px;
    margin: 5px auto;
    font-size: 14px;
}

.socials {
    list-style: none;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 1rem 0 1.5rem 0;
}

.socials li {
    margin: 0 10px;
}

.socials a {
    text-decoration: none;
    color: #fff;
}

.socials a i {
    font-size: 1.1rem;
}

.socials a:hover i {
    color: aqua;
}

.footer-links a {
    margin: 0 15px;
    color: #fff;
    text-decoration: none;
    font-size: 14px;
}

.footer-bottom {
    background: black;
    width: 100%;
    padding: 10px 0;
    text-align: center;
}

.footer-bottom p {
    font-size: 14px;
    word-spacing: 2px;
    text-transform: capitalize;
    font-family: forte, Arial, Helvetica, sans-serif;
}

.footer-bottom span {
    text-transform: uppercase;
    font-weight: 200;
    font-family: forte, Arial, Helvetica, sans-serif;
}
 /* Side button */
.side-button {
            position: fixed;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            background-color: #333;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .side-button:hover {
            background-color: #575757;
        }
    </style>
</head>
<body>
    <!--header banner-->
    <header>
        <nav class="navbar">
            <ul class="nav-links">
                <li><a href="admindashboard.php">Home</a></li>
                <li><a href="useraccounts.php">accounts</a></li>
                <li><a href="adminlogin.php">logout</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <h1>Admin Dashboard</h1>
        <div class="section" id="animals-section">
            <h2>Animals</h2>
            <!-- Animal management section -->
            <?php include '../animals.php'; ?>
        </div>
        <div class="section" id="breeding-section">
            <h2>Breeding</h2>
            <!-- Breeding records management section -->
            <?php include '../breeding.php'; ?>
        </div>
        <div class="section" id="feeding-section">
            <h2>Feeding</h2>
            <!-- Feeding schedule management section -->
            <?php include '../feeding.php'; ?>
        </div>
        <div class="section" id="finance-section">
            <h2>Finance</h2>
            <!-- Finance management section -->
            <?php include '../finance.php'; ?>
        </div>
        <div class="section" id="medical-section">
            <h2>Medical Records</h2>
            <!-- Medical records management section -->
            <?php include '../medical.php'; ?>
        </div>
    </div>
    <button class="side-button" id="side-button">Next Section</button>
    <script>
//JavaScript for side button to enable transversal within the page
const sections = document.querySelectorAll('.section');
        let currentIndex = 0;

        document.getElementById('side-button').addEventListener('click', () => {
            currentIndex = (currentIndex + 1) % sections.length;
            sections[currentIndex].scrollIntoView({ behavior: 'smooth' });
        });

        // JavaScript for interacting with managing animals
function createAnimal(typeID, name, dateOfBirth, gender, color, weight, birthplace) {
    // Open database connection
    var request = window.indexedDB.open('animalDB', 1);

    // Handle database opening
    request.onerror = function(event) {
        console.log("Database error: " + event.target.errorCode);
    };

    request.onsuccess = function(event) {
        var db = event.target.result;

        // Start a transaction
        var transaction = db.transaction(['animals'], 'readwrite');
        var objectStore = transaction.objectStore('animals');

        // Add new animal to the object store
        var request = objectStore.add({
            typeID: typeID,
            name: name,
            dateOfBirth: dateOfBirth,
            gender: gender,
            color: color,
            weight: weight,
            birthplace: birthplace
        });

        // Handle result of adding new animal
        request.onsuccess = function(event) {
            console.log("New animal added successfully!");
        };

        request.onerror = function(event) {
            console.log("Error adding new animal: " + event.target.errorCode);
        };
    };
}
// JavaScript for interacting with managing breeding records
function createBreedingRecord(parent1ID, parent2ID, dateOfBreeding, numberOfOffspring, breedingLocation, notes) {
    // Open database connection
    var request = window.indexedDB.open('breedingDB', 1);

    // Handle database opening
    request.onerror = function(event) {
        console.log("Database error: " + event.target.errorCode);
    };

    request.onsuccess = function(event) {
        var db = event.target.result;

        // Start a transaction
        var transaction = db.transaction(['breeding'], 'readwrite');
        var objectStore = transaction.objectStore('breeding');

        // Add new breeding record to the object store
        var request = objectStore.add({
            parent1ID: parent1ID,
            parent2ID: parent2ID,
            dateOfBreeding: dateOfBreeding,
            numberOfOffspring: numberOfOffspring,
            breedingLocation: breedingLocation,
            notes: notes
        });

        // Handle result of adding new breeding record
        request.onsuccess = function(event) {
            console.log("New breeding record added successfully!");
        };

        request.onerror = function(event) {
            console.log("Error adding new breeding record: " + event.target.errorCode);
        };
    };
}
// JavaScript for interacting with managing feeding schedules
function createFeedingSchedule(animalID, feedTime, feedType, quantity, location) {
    // Open database connection
    var request = window.indexedDB.open('feedingDB', 1);

    // Handle database opening
    request.onerror = function(event) {
        console.log("Database error: " + event.target.errorCode);
    };

    request.onsuccess = function(event) {
        var db = event.target.result;

        // Start a transaction
        var transaction = db.transaction(['feeding'], 'readwrite');
        var objectStore = transaction.objectStore('feeding');

        // Add new feeding schedule to the object store
        var request = objectStore.add({
            animalID: animalID,
            feedTime: feedTime,
            feedType: feedType,
            quantity: quantity,
            location: location
        });

        // Handle result of adding new feeding schedule
        request.onsuccess = function(event) {
            console.log("New feeding schedule added successfully!");
        };

        request.onerror = function(event) {
            console.log("Error adding new feeding schedule: " + event.target.errorCode);
        };
    };
}
// JavaScript for interacting with for managing finance records
function createFinanceRecord(animalID, transactionDate, transactionType, amount, buyerSellerName, transactionNotes) {
    // Open database connection
    var request = window.indexedDB.open('financeDB', 1);

    // Handle database opening
    request.onerror = function(event) {
        console.log("Database error: " + event.target.errorCode);
    };

    request.onsuccess = function(event) {
        var db = event.target.result;

        // Start a transaction
        var transaction = db.transaction(['finance'], 'readwrite');
        var objectStore = transaction.objectStore('finance');

        // Add new finance record to the object store
        var request = objectStore.add({
            animalID: animalID,
            transactionDate: transactionDate,
            transactionType: transactionType,
            amount: amount,
            buyerSellerName: buyerSellerName,
            transactionNotes: transactionNotes
        });

        // Handle result of adding new finance record
        request.onsuccess = function(event) {
            console.log("New finance record added successfully!");
        };

        request.onerror = function(event) {
            console.log("Error adding new finance record: " + event.target.errorCode);
        };
    };
}
// JavaScript for interacting with managing medical records
function createMedicalRecord(animalID, dateOfVisit, veterinarian, diagnosis, treatment, prescription, cost) {
    // Open database connection
    var request = window.indexedDB.open('medicalDB', 1);

    // Handle database opening
    request.onerror = function(event) {
        console.log("Database error: " + event.target.errorCode);
    };

    request.onsuccess = function(event) {
        var db = event.target.result;

        // Start a transaction
        var transaction = db.transaction(['medical'], 'readwrite');
        var objectStore = transaction.objectStore('medical');

        // Add new medical record to the object store
        var request = objectStore.add({
            animalID: animalID,
            dateOfVisit: dateOfVisit,
            veterinarian: veterinarian,
            diagnosis: diagnosis,
            treatment: treatment,
            prescription: prescription,
            cost: cost
        });

        // Handle result of adding new medical record
        request.onsuccess = function(event) {
            console.log("New medical record added successfully!");
        };

        request.onerror = function(event) {
            console.log("Error adding new medical record: " + event.target.errorCode);
        };
    };
}
    </script>
</body>
</html>
