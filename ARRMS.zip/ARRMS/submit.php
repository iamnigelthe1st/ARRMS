<?php
@session_start();
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "arrms";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

// Prepare SQL statement
$stmt = $conn->prepare("INSERT INTO Ranchers (FirstName, LastName, ContactNumber, Email, Address, Password, Gender, DateOfBirth) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

// Bind parameters
$stmt->bind_param("ssssssss", $firstName, $lastName, $contactNumber, $email, $address, $password, $gender, $dateOfBirth);

// Set parameters from form submission
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$contactNumber = $_POST['contactNumber'];
$email = $_POST['email'];
$address = $_POST['address'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password for security
$gender = $_POST['gender'];
$dateOfBirth = $_POST['dateOfBirth'];

// Execute the statement
if ($stmt->execute()) {
    $message = "New record created successfully";

    // Redirect to login.php after successful submission
    header("Location: login.php");
    exit(); // Ensure no further PHP execution
} else {
    $message = "Error: " . $stmt->error;
}

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<link rel="stylesheet" href="./css/home.css">
</head>
<body>
    <!--header banner-->
<header>
        <nav class="navbar">
            <a href="register.php" class="logo">ARRMS:REGISTER</a>
            <ul class="nav-links">
                <li><a href="home.php">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
                <li><a href="#">Contact Us</a></li>
            </ul>
        </nav>
    </header>
<br>
    <!--main content-->
<h2>Form Submission Result</h2>
    <p><?php echo isset($message) ? $message : ''; ?></p>
    <br>
    <!--footer--->
<footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Recording Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
                <a href="#">Home</a>
                <a href="#">About Us</a>
                <a href="#">Login</a>
                <a href="#">Registration</a>
                <a href="#">Contact Us</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
</body>
</html>
