<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
</head>
<body>
    <!--header banner-->
    <header>
        <nav class="navbar">
            <a href="home.php" class="logo">ARRMS:Home</a>
            <ul class="nav-links">
                <li><a href="/">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
                <li><a href="#">Contact Us</a></li>
            </ul>
        </nav>
    </header>
    <br>
    <!--content-->
    <div class="gallery">
        <div class="image-container">
            <img src="./images/home1.jpg" alt="">
            <div class="text">Welcome to ARRMS</div>
        </div>
        <div class="image-container">
            <img src="./images/home2.jpg" alt="">
            <div class="text">Web application designed to cater for recording and keeping tabs of farm records</div>
        </div>
        <div class="image-container">
            <img src="./images/home3.jpg" alt="">
            <div class="text">This Web application focuses on improving record keeping of various ranching activities</div>
        </div>
        <div class="image-container">
            <img src="./images/home4.jpg" alt="">
            <div class="text">Record keeping made easier by the ARRMS</div>
        </div>
    </div>
<br>

    <!--footer--->
    <footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Recording Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
                <a href="#">Home</a>
                <a href="#">About Us</a>
                <a href="#">Login</a>
                <a href="#">Registration</a>
                <a href="#">Contact Us</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
</body>
</html>