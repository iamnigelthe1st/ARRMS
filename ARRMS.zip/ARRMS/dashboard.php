<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
    <style>
        .dashboard {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            padding: 20px;
        }

        .user-card,
        .Animal-section,
        .production-section,
        .finances-section,
        .medical-section,
        .breeding-section,
        .feeding-section,
        .reports-section {
            flex: 1;
            min-width: 300px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
        }
        /*
        .user-card img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
        }*/

        .table-container {
            margin-top: 20px;
        }

        .button-container {
            margin-top: 20px;
        }

        .button-container button {
            background-color: #917e18;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .Animal-section{
            background-image: url();
        }
    </style>
</head>
<body>
    <!--header banner-->
    <header>
        <nav class="navbar">
            <a href="dashboard.php" class="logo">ARRMS:Dashboard</a>
            <ul class="nav-links">
                <li><a href="home.php">Home</a></li>
                <li><a href="Main.php">Main</a></li>
                <li><a href="user.php">User Profile</a></li>
                <li><a href="login.php">LogOut</a></li>
                
            </ul>
        </nav>
    </header>
    <br>
    <main>
        <div class="dashboard">
            <!-- User Card -->
            <div class="user-card">
                <h3>Welcome, User!</h3>
                <div>
                    <i class="fa fa-user"></i>
                    <span>Role: <?php print_r($_SESSION['user_type']);?></span><br>
                    <span>Name: <?php print_r($_SESSION['name'] );?></span>
                </div>
                <div class="button-container">
                    <button onclick="location.href='home.html'">Logout</button>
                </div>
            </div>
    
            <!-- Viewing Section -->
            <div class="Animal-section">
                <h3>Animals Section</h3>
                <div class="table-container">
                    <!-- Display data in a table format -->
                    <table>
                        <!-- Table content here -->
                    </table>
                </div>
                <div class="button-container">
                <button onclick="location.href='animals.php'">Animals</button>
                </div>
            </div>
    
            <!-- Finances Section -->
            <div class="finances-section">
                <h3>Finances Section</h3>
                <!-- Display numbers for money spent -->
                <!-- ... -->
                <form action="finance.php" method="post">
                    <!-- Form content for add/view finances -->
                    <!-- ... -->
                    <div class="button-container">
                    <button onclick="location.href='finance.php'">Add Finance info</button>
                    </div>
                </form>
            </div>
    
            <!-- Medical Section -->
            <div class="medical-section">
                <h3>Medical Section</h3>
                <form action="medical.php" method="post">
                    <!-- Form content for viewing medical records and adding records -->
                    <!-- ... -->
                    <div class="button-container">
                    <button onclick="location.href='medical.php'">Add Medical info</button>
                    </div>
                </form>
            </div>
    
            <!-- Breeding Section -->
            <div class="breeding-section">
                <h3>Breeding Section</h3>
                <!-- Display data from the database for breeding -->
                <!-- ... -->
                <div class="button-container">
                    <button onclick="location.href='breeding.php'">Add Breeding Info</button>
                </div>
            </div>
    
            <!-- Feeding Section -->
                        <div class="feeding-section">
                            <h3>Feeding Section</h3>
                            <!-- Display data from the database for Feeding -->
                            <!-- ... -->
                            <div class="button-container">
                                <button onclick="location.href='feeding.php'">Add Feeding Info</button>
                            </div>
                        </div>

            <!-- Reports Section -->
            <div class="reports-section">
                <h3>Reports Section</h3>
                <div class="button-container">
                <a href="report.php?type=Animal" >Animals Report</a>
                <a href="report.php?type=Breeding" >Breeding Report</a>
                <a href="report.php?type=Finances" >Finances Report</a>
                <a href="report.php?type=Medical" >Medical Report</a>
                <a href="report.php?type=Feeding" >Feeding Report</a>
                </div>
            </div>
        </div>
    </main>
    <!--footer--->
    <footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Records Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
                <a href="home.php">Home</a>
                <a href="#">About Us</a>
                <a href="login.php">Login</a>
                <a href="register.php">Sign Up</a>
                <a href="#">Contact Us</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
    <script>
    // Function to toggle the visibility of table containers
    function toggleTable(sectionId) {
        var tableContainer = document.getElementById(sectionId + "-table");
        if (tableContainer.style.display === "none") {
            tableContainer.style.display = "block";
        } else {
            tableContainer.style.display = "none";
        }
    }

    // Function to highlight the selected section
    function highlightSection(sectionId) {
        var sections = document.querySelectorAll(".section");
        sections.forEach(function(section) {
            section.classList.remove("highlighted");
        });
        var selectedSection = document.getElementById(sectionId);
        selectedSection.classList.add("highlighted");
    }
</script>
</body>
</html>