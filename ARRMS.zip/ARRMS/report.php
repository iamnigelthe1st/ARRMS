<?php
@session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

$fileType = $_GET['type'];
// Excel file name for download 
$fileName = $fileType."-" . date('Y-m-d') . ".xls"; 
$fields = "";
$lineData = "";
$excelData="";

switch ($fileType) {
    case 'Animal':
        //column names
        $fields = array('AnimalID', 'NAME', 'Date Of Birth',  'Gender'); 
        
        //set column names as the first row to appear
        $excelData = implode("\t", array_values($fields)) . "\n"; 
        
        //fetch from db
        $sql = "SELECT * FROM Animals";
        $result=mysqli_query($conn, $sql);
        while($c=mysqli_fetch_assoc($result)){
            $lineData = array($c['AnimalID'],$c['NAME'],$c['DateOfBirth'], $c['Gender']); 
            array_walk($lineData, 'filterData'); 
            $excelData .= implode("\t", array_values($lineData)) . "\n"; 
        }
        break;
    
    case 'Breeding':
        //column names
        $fields = array('BreedingID', 'Parent1','Parent2', 'Date Of Breeding',  'Breeding Location', 'Number of Offsprings'); 
        
        //set column names as the first row to appear
        $excelData = implode("\t", array_values($fields)) . "\n"; 
        
        //fetch from db
        $sql = "SELECT b.*, a.NAME as parent1, ab.NAME as parent2 FROM breedingrecords b 
        LEFT JOIN animals a on a.AnimalID = b.Parent1ID 
        LEFT JOIN animals ab on ab.AnimalID = b.Parent2ID";
        $result=mysqli_query($conn, $sql);
        while($c=mysqli_fetch_assoc($result)){
            $lineData = array($c['BreedingID'],$c['parent1'],$c['parent2'],$c['DateOfBreeding'], $c['BreedingLocation'], $c['NumberOfOffspring']); 
            array_walk($lineData, 'filterData'); 
            $excelData .= implode("\t", array_values($lineData)) . "\n"; 
        }
        break;
    
    case 'Finances':
        //column names
        $fields = array('TransactionID', 'Animal Name','Transaction Date', 'Tranasction Type',  'Amount', 'Buyer Name'); 
        
        //set column names as the first row to appear
        $excelData = implode("\t", array_values($fields)) . "\n"; 
        
        //fetch from db
        $sql = "SELECT f.*, a.NAME as name FROM salestransfers f 
        LEFT JOIN animals a on a.AnimalID = f.AnimalID";
        $result=mysqli_query($conn, $sql);
        while($c=mysqli_fetch_assoc($result)){
            $lineData = array($c['TransactionID'],$c['name'],$c['TransactionDate'],$c['TransactionType'], $c['Amount'], $c['BuyerSellerName']); 
            array_walk($lineData, 'filterData'); 
            $excelData .= implode("\t", array_values($lineData)) . "\n"; 
        }
        break;

    case 'Medical':
        //column names
        $fields = array('RecordID', 'Animal Name','Date of Visit', 'Vet.',  'Diagnosis', 'Treatment', 'Prescription', 'Cost') ; 
        
        //set column names as the first row to appear
        $excelData = implode("\t", array_values($fields)) . "\n"; 
        
        //fetch from db
        $sql = "SELECT m.*, a.NAME as name FROM medicalrecords m 
        LEFT JOIN animals a on a.AnimalID = m.AnimalID";
        $result=mysqli_query($conn, $sql);
        while($c=mysqli_fetch_assoc($result)){
            $lineData = array($c['RecordID'],$c['name'],$c['DateOfVisit'],$c['Veterinarian'], $c['Diagnosis'], $c['Treatment'], $c['Prescription'], $c['Cost']); 
            array_walk($lineData, 'filterData'); 
            $excelData .= implode("\t", array_values($lineData)) . "\n"; 
        }
        break;
    
        case 'Feeding':
            //column names
            $fields = array('ScheduleID', 'AnimalID', 'FeedTime', 'FeedType', 'Quantity', 'Location');
            
            //set column names as the first row to appear
            $excelData = implode("\t", array_values($fields)) . "\n";
            
            //fetch from db
            $sql = "SELECT * FROM FeedingSchedule";
            $result = mysqli_query($conn, $sql);
            while($c = mysqli_fetch_assoc($result)){
                $lineData = array($c['ScheduleID'], $c['AnimalID'], $c['FeedTime'], $c['FeedType'], $c['Quantity'], $c['Location']);
                array_walk($lineData, 'filterData');
                $excelData .= implode("\t", array_values($lineData)) . "\n";
            }
            break;
}

header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 

// Render excel data 
echo $excelData; 

exit;

?>