<?php
@session_start();
// Assuming database connection details are provided here
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from database
$sql = "SELECT * FROM SalesTransfers";
$result = $conn->query($sql);

$schedules = [];

    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            $schedules[] = $row;
        }
    }

if (!empty($_POST)){

    // Optionally set character set to utf8 (if you're dealing with non-English characters)
    $conn->set_charset("utf8");
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Get form data
            $animalID = $_POST['animalID'];
            $transactionDate = $_POST['transactionDate'];
            $transactionType = $_POST['transactionType'];
            $amount = $_POST['amount'];
            $buyerSellerName = $_POST['buyerSellerName'];
            $transactionNotes = $_POST['transactionNotes'];
    
    //     $stmt = $conn->prepare("INSERT INTO Admin (Username, PASSWORD, FirstName, LastName, Email) VALUES (?, ?, ?, ?, ?)");
    // if ($stmt->execute([$username, $password, $firstName, $lastName, $email])) {
        // Parent1ID`, `Parent2ID`, `DateOfBreeding`, `NumberOfOffspring`, `BreedingLocation`, `Notes`
    
        // Insert data into breedingrecords table
        $sql = "INSERT INTO salestransfers ( `AnimalID`, `TransactionDate`, `TransactionType`, `Amount`, `BuyerSellerName`, `TransactionNotes`)
        VALUES(?, ?, ?, ?, ?, ?)";
        if ($stmt = $conn->prepare($sql)) {
            // $stmt->bind_param("isss", $animalName, $animalDOB, $animalGender);
            if ($stmt->execute([$animalID, $transactionDate, $transactionType, $amount, $buyerSellerName, $transactionNotes])) {
                header('Location: http://localhost/ARRMS/ARRMS/ARRMS/finance.php');
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            $stmt->close();
        }
        $conn->close();
    }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
    <style>
        section {
            margin: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        form {
            margin-top: 20px;
        }

        label, input, select {
            display: block;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!--header banner-->
    <header>
        <nav class="navbar">
            <a href="#" class="logo">ARRMS:Home</a>
            <ul class="nav-links">
            <li><a href="home.php">Home</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="login.php">LogOut</a></li>
            </ul>
        </nav>
    </header>
    <br>
    <!--main content-->
    <fieldset>
    <section>
        <h2>View Sales and Transfers</h2>
        <table>
            <thead>
                <tr>
                    <th>Transaction ID</th>
                    <th>Animal ID</th>
                    <th>Transaction Date</th>
                    <th>Transaction Type</th>
                    <th>Amount</th>
                    <th>Buyer/Seller Name</th>
                    <th>Transaction Notes</th>
                    
                    <?php 
                    
                        if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== "rancher"){
                            print_r("<th>Action</th>");
                        }
                    ?>
                        <fieldset>
    <section>
        <h2>Add Sales or Transfer Record</h2>
        <form  method="POST" action="finance.php">
            <label for="animalID">Animal ID:</label>
            <input type="number" id="animalID" name="animalID" required>

            <label for="transactionDate">Transaction Date:</label>
            <input type="date" id="transactionDate" name="transactionDate" required>

            <label for="transactionType">Transaction Type:</label>
            <select id="transactionType" name="transactionType" required>
                <option value="Sale">Sale</option>
                <option value="Transfer">Transfer</option>
            </select>

            <label for="amount">Amount:</label>
            <input type="number" id="amount" name="amount" step="0.01" required>

            <label for="buyerSellerName">Buyer/Seller Name:</label>
            <input type="text" id="buyerSellerName" name="buyerSellerName" required>

            <label for="transactionNotes">Transaction Notes:</label>
            <textarea id="transactionNotes" name="transactionNotes" rows="4"></textarea>

            <button type="submit">Add Sales or Transfer Record</button>
        </form>
    </section>
    </fieldset>
                </tr>
            </thead>
            <tbody>
                <!-- Sales and transfers records data will be dynamically populated here -->
                <?php 
                    foreach ($schedules as $schedule) {
                        print_r("
                        <tr>
                            <td>".$schedule['TransactionID']."</td>
                            <td>".$schedule['AnimalID']."</td>
                            <td>".$schedule['TransactionDate']."</td>
                            <td>".$schedule['TransactionType']."</td>
                            <td>".$schedule['Amount']."</td>
                            <td>".$schedule['BuyerSellerName']."</td>
                            <td>".$schedule['TransactionNotes']."</td>");
                            
                            if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== "rancher"){
                                print_r("<td>
                                <button>
                                    <a style='color:white;' href='http://localhost/ARRMS/ARRMS/ARRMS/admin/updateFinance.php?id=".$schedule['TransactionID']."'>Edit</a>
                                </button>
                                <button style='float:right;'>
                                    <a style='color:white;' href='http://localhost/ARRMS/ARRMS/ARRMS/admin/delete.php?id=".$schedule['TransactionID']."&table=finance'>Delete</a>
                                </button>
                                </td>");
                            }
                
                            print_r("</tr>");
                    }
                ?>
            </tbody>
        </table>
    </section>
    </fieldset>
    <br>
    <br>
    <!--footer--->
    <footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Records Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
            <li><a href="home.php">Home</a></li>
                <li><a href="register.php">Sign Up</a></li>
                <li><a href="login.php">Logout</a></li>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
    <script>
    // Add your JavaScript code for interacting with the database here
    // Populate table with fetched data
//     document.addEventListener("DOMContentLoaded", function () {
//     var salesTransfers = <?php echo json_encode($rows); ?>;
//     var tbody = document.querySelector("tbody");

//     salesTransfers.forEach(function (transaction) {
//         var row = document.createElement("tr");

//         Object.values(transaction).forEach(function (value) {
//             var cell = document.createElement("td");
//             cell.textContent = value;
//             row.appendChild(cell);
//         });

//         tbody.appendChild(row);
//     });
// });

// // Function to add sales or transfer record
// document.getElementById("addSalesTransferForm").addEventListener("submit", function (event) {
//     event.preventDefault(); // Prevent the form from submitting normally

//     var formData = new FormData(this);

//     // Prepare the data to be sent to the server
//     var requestData = {
//         method: 'POST',
//         body: formData
//     };

//     // Send the request to the server-side script
//     fetch('data_handler.php', requestData)
//         .then(response => response.json())
//         .then(data => {
//             // Handle response from the server
//             console.log(data);
//             // Optionally, you can update the table here to display the newly added record
//         })
//         .catch(error => {
//             console.error("Error:", error);
//         });
// });

//     function goToDashboard() {
//         // Redirect to the dashboard page
//         window.location.href = 'dashboard.html';
//     }
</script>
</body>
</html>