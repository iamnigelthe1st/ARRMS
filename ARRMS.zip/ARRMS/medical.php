<?php
@session_start();
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "arrms";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to escape string to prevent SQL injection
function escapeString($conn, $value) {
    return $conn->real_escape_string($value);
}



    // Fetch feeding schedules
    $sql = "SELECT * FROM MedicalRecords";
    $result = $conn->query($sql);

    $schedules = [];

    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            $schedules[] = $row;
        }
    }

    if (!empty($_POST)){

        // Optionally set character set to utf8 (if you're dealing with non-English characters)
        $conn->set_charset("utf8");
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Get form data 
            $animalID = $_POST['animalID'];
            $dateOfVisit = $_POST['dateOfVisit'];
            $veterinarian = $_POST['veterinarian'];
            $diagnosis = $_POST['diagnosis'];
            $treatment = $_POST['treatment'];
            $prescription = $_POST['prescription'];
            $cost = $_POST['cost'];
        
        //     $stmt = $conn->prepare("INSERT INTO Admin (Username, PASSWORD, FirstName, LastName, Email) VALUES (?, ?, ?, ?, ?)");
        // if ($stmt->execute([$username, $password, $firstName, $lastName, $email])) {
            // Parent1ID`, `Parent2ID`, `DateOfBreeding`, `NumberOfOffspring`, `BreedingLocation`, `Notes`
        
            // Insert data into breedingrecords table
            
            $sql = "INSERT INTO `medicalrecords`(`AnimalID`, `DateOfVisit`, `Veterinarian`, `Diagnosis`, `Treatment`, `Prescription`, `Cost`) VALUES(?, ?, ?, ?, ?, ?, ?)";
            if ($stmt = $conn->prepare($sql)) {
                // $stmt->bind_param("isss", $animalName, $animalDOB, $animalGender);
                if ($stmt->execute([$animalID, $dateOfVisit, $veterinarian, $diagnosis, $treatment, $prescription, $cost])) {
                    echo "Feeding Schedule added successfully!</br><a href='http://localhost/ARRMS/ARRMS/ARRMS/admin/admindashboard.php'>Back to dashboard</a>";
                    header('Location: http://localhost/ARRMS/ARRMS/ARRMS/medical.php');
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
                $stmt->close();
            }
            $conn->close();
        }
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
    <style>
        section {
            margin: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        form {
            margin-top: 20px;
        }

        label, input, select {
            display: block;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!--header banner-->
    <header>
        <nav class="navbar">
            <a href="medical.php" class="logo">ARRMS:Medical</a>
            <ul class="nav-links">
            <li><a href="home.php">Home</a></li>
                <li><a href="register.php">Sign Up</a></li>
                <li><a href="login.php">Logout</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
            </ul>
        </nav>
    </header>
    <br>
    <br>
    <!--main content-->
<fieldset>
    <section>
        <h2>View Medical Records</h2>
        <table>
            <thead>
                <tr>
                    <th>Record ID</th>
                    <th>Animal ID</th>
                    <th>Date of Visit</th>
                    <th>Veterinarian</th>
                    <th>Diagnosis</th>
                    <th>Treatment</th>
                    <th>Prescription</th>
                    <th>Cost</th>
                    <?php 
                    
                        if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== "rancher"){
                            print_r("<th>Action</th>");
                        }
                    ?>
                    <fieldset>
    <section>
        <h2>Add Medical Record</h2>
        <form  method="POST" action="medical.php">
            <label for="animalID">Animal ID:</label>
            <input type="number" id="animalID" name="animalID" required>

            <label for="dateOfVisit">Date of Visit:</label>
            <input type="date" id="dateOfVisit" name="dateOfVisit" required>

            <label for="veterinarian">Veterinarian:</label>
            <input type="text" id="veterinarian" name="veterinarian" required>

            <label for="diagnosis">Diagnosis:</label>
            <input type="text" id="diagnosis" name="diagnosis" required>

            <label for="treatment">Treatment:</label>
            <input type="text" id="treatment" name="treatment" required>

            <label for="prescription">Prescription:</label>
            <textarea id="prescription" name="prescription" rows="4"></textarea>

            <label for="cost">Cost:</label>
            <input type="number" id="cost" name="cost" step="0.01" required>

            <button type="submit">Add Medical Record</button>
        </form>
    </section>
    </fieldset>
                </tr>
            </thead>
            <tbody>
                <?php 
                    foreach ($schedules as $schedule) {
                        print_r("
                        <tr>
                            <td>".$schedule['RecordID']."</td>
                            <td>".$schedule['AnimalID']."</td>
                            <td>".$schedule['DateOfVisit']."</td>
                            <td>".$schedule['Veterinarian']."</td>
                            <td>".$schedule['Diagnosis']."</td>
                            <td>".$schedule['Treatment']."</td>
                            <td>".$schedule['Prescription']."</td>
                            <td>".$schedule['Cost']."</td> ");
                    
                        if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== "rancher"){
                            print_r("<td>
                            <button>
                                <a style='color:white;' href='http://localhost/ARRMS/ARRMS/ARRMS/admin/updateMedical.php?id=".$schedule['RecordID']."'>Edit</a>
                            </button>
                            <button style='float:right;'>
                                <a style='color:white;' href='http://localhost/ARRMS/ARRMS/ARRMS/admin/delete.php?id=".$schedule['RecordID']."&table=medical'>Delete</a>
                            </button>
                            </td>");
                        }
                    print_r("</tr>");
                    }
                ?>
            </tbody>
        </table>
    </section>
</fieldset>
    <br>
    
    <br>
    <br>
    <!--footer--->
    <footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Recording Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
            <li><a href="home.php">Home</a></li>
                <li><a href="register.php">Sign Up</a></li>
                <li><a href="login.php">Logout</a></li>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
</body>
</html>