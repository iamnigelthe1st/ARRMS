<?php
@session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Rancher Registration Form</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<link rel="stylesheet" href="./css/home.css">
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 600px;
        margin: 50px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    h2 {
        text-align: center;
        margin-bottom: 20px;
    }
    label {
        display: block;
        margin-bottom: 5px;
    }
    input[type="text"],
    input[type="email"],
    input[type="date"],
    select {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    input[type="submit"],[type="reset"]{
        background-color: #4CAF50;
        color: white;
        padding: 15px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
    }
</style>
<!--JavaScript for validation of the fields-->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Get form element
        var form = document.querySelector('form');

        // Add submit event listener to the form
        form.addEventListener('submit', function (event) {
            // Prevent the default form submission
            event.preventDefault();

            // Validate form fields
            var firstName = document.getElementById('firstName').value.trim();
            var lastName = document.getElementById('lastName').value.trim();
            var gender = document.getElementById('gender').value;
            var dateOfBirth = new Date(document.getElementById('dateOfBirth').value);
            var contactNumber = document.getElementById('contactNumber').value.trim();
            var email = document.getElementById('email').value.trim();
            var address = document.getElementById('address').value.trim();
            var password = document.getElementById('password').value.trim();
            var confirmPassword = document.getElementById('confirmPassword').value.trim();

            // Check if all fields are filled
            if (!firstName || !lastName || !gender || !dateOfBirth || !contactNumber || !email || !address || !password || !confirmPassword) {
                alert('All fields are required');
                return;
            }
            console.log(password);

            // Check if first name and last name are valid (minimum 3 characters, no special characters, no numbers)
            var namePattern = /^[a-zA-Z]{3,}$/;
            if (!namePattern.test(firstName)) {
                alert('First name must be at least 3 characters long and contain only letters');
                return;
            }
            if (!namePattern.test(lastName)) {
                alert('Last name must be at least 3 characters long and contain only letters');
                return;
            }

            // Check if email contains '@'
            if (email.indexOf('@') === -1) {
                alert('Invalid email address');
                return;
            }

            // Check if contact number is 10 digits
            if (contactNumber.length !== 10) {
                alert('Contact number should be 10 digits');
                return;
            }

            // Calculate age based on date of birth
            var currentDate = new Date();
            var age = currentDate.getFullYear() - dateOfBirth.getFullYear();
            var birthMonth = dateOfBirth.getMonth();
            var currentMonth = currentDate.getMonth();
            if (currentMonth < birthMonth || (currentMonth === birthMonth && currentDate.getDate() < dateOfBirth.getDate())) {
                age--;
            }

            // Check if age is 18 or above
            if (age < 18) {
                alert('You must be 18 years or older to register');
                return;
            }

            // If all validations pass, submit the form
            form.submit();
        });
    });
</script>

</head>
<body>
<!--header banner-->
<header>
        <nav class="navbar">
            <a href="register.php" class="logo">ARRMS:REGISTER</a>
            <ul class="nav-links">
                <li><a href="home.php">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
                <li><a href="#">Contact Us</a></li>
            </ul>
        </nav>
    </header>
<br>
    <!--content--->
    <h2>Rancher Registration Form</h2>
    <div class="container">
<fieldset>
<form action="submit.php" method="POST">
    <label for="firstName">First Name:</label><br>
    <input type="text" id="firstName" name="firstName" required><br><br>

    <label for="lastName">Last Name:</label><br>
    <input type="text" id="lastName" name="lastName" required><br><br>

    <label for="gender">Gender:</label><br>
    <select id="gender" name="gender">
        <option value="male">Male</option>
        <option value="female">Female</option>
    </select><br><br>

    <label for="dateOfBirth">Date of Birth:</label><br>
    <input type="date" id="dateOfBirth" name="dateOfBirth"><br><br>

    <label for="contactNumber">Contact Number:</label><br>
    <input type="tel" id="contactNumber" name="contactNumber"><br><br>

    <label for="email">Email:</label><br>
    <input type="email" id="email" name="email"><br><br>

    <label for="address">Address:</label><br>
    <textarea id="address" name="address" rows="4"></textarea><br><br>

    <label for="password">Password:</label><br>
    <input type="password" id="password" name="password" required><br><br>

    <label for="confirmPassword">Confirm Password:</label><br>
    <input type="password" id="confirmPassword" name="confirmPassword" required><br><br>

    <input type="submit" value="Submit">
    <input type="Reset" value="reset">
</form>
</fieldset>
</div>
<br>
<!--footer--->
<footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Recording Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
                <a href="home.php">Home</a>
                <a href="#">About Us</a>
                <a href="login.php">Login</a>
                <a href="register.php">Registration</a>
                <a href="#">Contact Us</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
</body>
</html>
