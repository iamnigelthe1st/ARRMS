<?php
@session_start();
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Insert feeding schedule
    $animalID = $_POST['animalID'];
    $feedTime = $_POST['feedTime'];
    $feedType = $_POST['feedType'];
    $quantity = $_POST['quantity'];
    $location = $_POST['location'];

    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO FeedingSchedule (AnimalID, FeedTime, FeedType, Quantity, Location) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isssd", $animalID, $feedTime, $feedType, $quantity, $location);

    // Execute SQL statement
    if ($stmt->execute() === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    // Fetch feeding schedules
    $sql = "SELECT * FROM FeedingSchedule";
    $result = $conn->query($sql);
    $schedules = [];

    if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
            $schedules[] = $row;
        }
    }

    // Output feeding schedules as JSON
    // header('Content-Type: application/json');
    // echo json_encode($schedules);
}

$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
    <style>
        section {
            margin: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        form {
            margin-top: 20px;
        }

        label, input, select {
            display: block;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!--header banner-->
    <header>
        <nav class="navbar">
            <a href="feeding.php" class="logo">ARRMS:Feeding</a>
            <ul class="nav-links">
                <li><a href="home.php">Home</a></li>
                <li><a href="login.php">Logout</a></li>
                <li><a href="Dashboard.php">Dashboard</a></li>
            </ul>
        </nav>
    </header>
    <br>
    <br>
    <!--main content-->
<fieldset>
    <section>
        <h2>View Feeding Schedules</h2>
        <table>
            <thead>
                <tr>
                    <th>Schedule ID</th>
                    <th>Animal ID</th>
                    <th>Feed Time</th>
                    <th>Feed Type</th>
                    <th>Quantity</th>
                    <th>Location</th>
                    <th>Action</th>
                </tr>
            </thead>
            <fieldset>
                <br>
    <section>
        <h2>Add Feeding Schedule</h2>
        <form method="POST" action="feeding.php">
            <label for="animalID">Animal ID:</label>
            <input type="number" id="animalID" name="animalID" required>

            <label for="feedTime">Feed Time:</label>
            <input type="time" id="feedTime" name="feedTime" required>

            <label for="feedType">Feed Type:</label>
            <input type="text" id="feedType" name="feedType" required>

            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" step="0.01" required>

            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required>

            <button type="submit">Add Feeding Schedule</button>
        </form>
    </section>
</fieldset>
            <tbody>
                <!-- Feeding schedules data will be dynamically populated here -->
                <?php 
                foreach ($schedules as $schedule) {
                    print_r("
                    <tr>
                        <td>".$schedule['ScheduleID']."</td>
                        <td>".$schedule['AnimalID']."</td>
                        <td>".$schedule['FeedTime']."</td>
                        <td>".$schedule['FeedType']."</td>
                        <td>".$schedule['Quantity']."</td>
                        <td>".$schedule['Location']."</td>
                        <td>
                        <button>
                            <a style='color:white;' href='http://localhost/ARRMS/ARRMS/ARRMS/admin/updateFeeding.php?id=".$schedule['ScheduleID']."'>Edit</a>
                        </button>
                        <button style='float:right;'>
                            <a style='color:white;' href='http://localhost/ARRMS/ARRMS/ARRMS/admin/delete.php?id=".$schedule['ScheduleID']."&table=feeding'>Delete</a>
                        </button>
                        </td>
                    </tr>");
                }
                ?>
            </tbody>
        </table>
    </section>
</fieldset>
    <br>
    <br>
    <!--footer--->
    <footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Records Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
            <li><a href="home.php">Home</a></li>
                <li><a href="register.php">Sign Up</a></li>
                <li><a href="login.php">Logout</a></li>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>

    <script>
        // Function to fetch and display feeding schedules
    // function fetchFeedingSchedules() {
    //     fetch('fetch_feeding.php')
    //         .then(response => response.json())
    //         .then(data => {
    //             const tbody = document.querySelector('tbody');
    //             tbody.innerHTML = ''; // Clear existing table rows

    //             // Loop through fetched data and append to table
    //             data.forEach(schedule => {
    //                 const row = `<tr>
    //                                 <td>${schedule.ScheduleID}</td>
    //                                 <td>${schedule.AnimalID}</td>
    //                                 <td>${schedule.FeedTime}</td>
    //                                 <td>${schedule.FeedType}</td>
    //                                 <td>${schedule.Quantity}</td>
    //                                 <td>${schedule.Location}</td>
    //                             </tr>`;
    //                 tbody.innerHTML += row;
    //             });
    //         })
    //         .catch(error => console.error('Error:', error));
    // }

    // // Add event listener to form submission
    // document.getElementById('addFeedingScheduleForm').addEventListener('submit', function(event) {
    //     event.preventDefault(); // Prevent default form submission

    //     // Fetch form data
    //     const formData = new FormData(this);

    //     // Send form data to server using fetch API
    //     fetch('process_feeding.php', {
    //         method: 'POST',
    //         body: formData
    //     })
    //     .then(response => response.text())
    //     .then(data => {
    //         console.log(data); // Log server response
    //         // Fetch and display updated feeding schedules
    //         fetchFeedingSchedules();
    //     })
    //     .catch(error => console.error('Error:', error));
    // });

    // // Call fetchFeedingSchedules on page load
    // fetchFeedingSchedules();

    //     function goToDashboard() {
    //         // Redirect to the dashboard page
    //         window.location.href = 'dashboard.html';
    //     }
    </script>
</body>
</html>