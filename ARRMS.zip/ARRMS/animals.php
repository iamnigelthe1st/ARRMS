<?php
@session_start();
// print_r($_SESSION['user_type']);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (!empty($_POST)){
$conn->set_charset("utf8");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $animalName = $_POST['animalName'];
    $animalDOB = $_POST['animalDOB'];
    $animalGender = $_POST['animalGender'];

    // Insert data into Animals table
    $sql = "INSERT INTO Animals ( NAME, DateOfBirth, Gender) VALUES (?, ?, ?, ?)";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("isss", $animalType, $animalName, $animalDOB, $animalGender);
        if ($stmt->execute()) {
            echo "Animal added successfully!";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        $stmt->close();
    }
    $conn->close();
}
}
$sql = "SELECT * FROM Animals";
$animals=array();
$result=mysqli_query($conn, $sql);
while($c=mysqli_fetch_assoc($result)){
    array_push($animals, $c);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
    <style>
        section {
            margin: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        form {
            margin-top: 20px;
        }

        label, input {
            display: block;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        
    </style>
</head>
<body>
    <!--header banner-->
    <header>
        <nav class="navbar">
            <a href="animals.php" class="logo">ARRMS:Animals</a>
            <ul class="nav-links">
                <li><a href="home.php">Home</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="login.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <br>
    <br>
    <!--Content-->
    <section>
        <h2>View Animals</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Date of Birth</th>
                    <th>Gender</th>
                    
                    <?php 
                        if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== "rancher"){
                            print_r("<th>Action</th>");
                        }
                    ?>

                </tr>
            </thead>
            <tbody>

            <!--adding animals--->
        <?php 
            if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== "rancher"){
                print_r('
                <fieldset>
                <section>
                <h2>Add Animal</h2>
                <form id="addAnimalForm" method="post" action="animals.php">
                    
                    <label for="animalName">Name:</label>
                    <input type="text" id="animalName" name="animalName" required>

                    <label for="animalDOB">Date of Birth:</label>
                    <input type="date" id="animalDOB" name="animalDOB" required>

                    <label for="animalGender">Gender:</label>
                    <select id="animalGender" name="animalGender" required>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>

                    <button type="submit">Add Animal</button>
                </form>
                </section>
                </fieldset>
            ');
            }
        ?>

                <!-- Animal data will be dynamically populated here -->
                <?php 
                foreach ($animals as $animal) {
                    print_r('<tr>
                                <td>'.$animal['AnimalID'].'</td>
                                <td>'.$animal['NAME'].'</td>
                                <td>'.$animal['DateOfBirth'].'</td>
                                <td>'.$animal['Gender'].'</td>');
                                if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== "rancher"){
                                    print_r('
                                    <td>
                                    <button>
                                        <a style="color:white;" href="http://localhost/ARRMS/ARRMS/ARRMS/admin/updateAnimals.php?id='.$animal['AnimalID'].'">Edit</a>
                                    </button>
                                    <button style="float:right;">
                                    <a style="color:white;" href="http://localhost/ARRMS/ARRMS/ARRMS/admin/delete.php?id='.$animal['AnimalID'].'&table=animal">Delete</a>
                                    </button>
                                </td>

                                    ');
                                }
                                
                            print_r('</tr>');
                }?>
            </tbody>
        </table>
    </section>

    
    <br>
    <br>
    <!--footer--->
    <footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Records Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
            <li><a href="home.php">Home</a></li>
                <li><a href="register.php">Sign Up</a></li>
                <li><a href="login.php">Logout</a></li>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
    <script>
//     document.addEventListener("DOMContentLoaded", function() {
//     const addAnimalForm = document.getElementById('addAnimalForm');
//     addAnimalForm.addEventListener('submit', function(event) {
//         event.preventDefault();
//         const formData = new FormData(addAnimalForm);
//         fetch('animals.php', {
//             method: 'POST',
//             body: formData
//         })
//         .then(response => response.text())
//         .then(data => {
//             alert(data); // Display response from PHP (e.g., success message or error)
//             // You can optionally update the animal list here after successful submission
//         })
//         .catch(error => {
//             console.error('Error:', error);
//         });
//     });
// });

//     function goToDashboard() {
//         // Redirect to dashboard.html
//         window.location.href = 'dashboard.html';
//     }
</script>
</body>
</html>
