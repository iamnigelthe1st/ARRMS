<?php
@session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM BreedingRecords";
$breeding=array();
$result=mysqli_query($conn, $sql);
while($c=mysqli_fetch_assoc($result)){
    array_push($breeding, $c);
}


if (!empty($_POST)){

    // Optionally set character set to utf8 (if you're dealing with non-English characters)
    $conn->set_charset("utf8");
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Get form data
            $parent1ID = $_POST['parent1ID'];
            $parent2ID = $_POST['parent2ID'];
            $dateOfBreeding = $_POST['dateOfBreeding'];
            $numberOfOffspring = $_POST['numberOfOffspring'];
            $breedingLocation = $_POST['breedingLocation'];
            $notes = $_POST['notes'];
    
    //     $stmt = $conn->prepare("INSERT INTO Admin (Username, PASSWORD, FirstName, LastName, Email) VALUES (?, ?, ?, ?, ?)");
    // if ($stmt->execute([$username, $password, $firstName, $lastName, $email])) {
        // Parent1ID`, `Parent2ID`, `DateOfBreeding`, `NumberOfOffspring`, `BreedingLocation`, `Notes`
    
        // Insert data into breedingrecords table
        $sql = "INSERT INTO breedingrecords (Parent1ID, Parent2ID, DateOfBreeding, NumberOfOffspring, BreedingLocation,Notes ) VALUES (?, ?, ?, ?, ?, ?)";
        if ($stmt = $conn->prepare($sql)) {
            // $stmt->bind_param("isss", $animalName, $animalDOB, $animalGender);
            if ($stmt->execute([$parent1ID, $parent2ID, $dateOfBreeding, $numberOfOffspring, $breedingLocation, $notes])) {
                header('Location: http://localhost/ARRMS/ARRMS/ARRMS/breeding.php');
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
            $stmt->close();
        }
        $conn->close();
    }
    }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARRMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
    <style>
        section {
            margin: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        form {
            margin-top: 20px;
        }

        label, input, select {
            display: block;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!--header banner-->
    <header>
        <nav class="navbar">
            <a href="breeding.php" class="logo">ARRMS:Breeding</a>
            <ul class="nav-links">
                <li><a href="home.php">Home</a></li>
                <li><a href="login.php">Logout</a></li>
                <li><a href="dashboard.php">Dashboard</a></li>
            </ul>
        </nav>
    </header>
    <br>
    <br>
    <!--main content-->
    <fieldset>
    <section>
        <h2>View Breeding Records</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Parent 1 ID</th>
                    <th>Parent 2 ID</th>
                    <th>Date of Breeding</th>
                    <th>Number of Offspring</th>
                    <th>Breeding Location</th>
                    <th>Notes</th>

                    <?php 
                    
                        if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== "rancher"){
                            print_r("<th>Action</th>");
                        }
                    ?>
                </tr>
            </thead>
            <fieldset>
    <section>
        <h2>Add Breeding Record</h2>
        <form  method="POST" action="breeding.php">
            <label for="parent1ID">Parent 1 ID:</label>
            <input type="number" id="parent1ID" name="parent1ID" required>

            <label for="parent2ID">Parent 2 ID:</label>
            <input type="number" id="parent2ID" name="parent2ID" required>

            <label for="dateOfBreeding">Date of Breeding:</label>
            <input type="date" id="dateOfBreeding" name="dateOfBreeding" required>

            <label for="numberOfOffspring">Number of Offspring:</label>
            <input type="number" id="numberOfOffspring" name="numberOfOffspring" required>

            <label for="breedingLocation">Breeding Location:</label>
            <input type="text" id="breedingLocation" name="breedingLocation" required>

            <label for="notes">Notes:</label>
            <textarea id="notes" name="notes" rows="4"></textarea>

            <button type="submit">Add Breeding Record</button>
        </form>
    </section>
    </fieldset>
            <tbody>
            <?php 
                foreach ($breeding as $breed) {
                    print_r('<tr>
                                <td>'.$breed['BreedingID'].'</td>
                                <td>'.$breed['Parent1ID'].'</td>
                                <td>'.$breed['Parent2ID'].'</td>
                                <td>'.$breed['DateOfBreeding'].'</td>
                                <td>'.$breed['NumberOfOffspring'].'</td>
                                <td>'.$breed['BreedingLocation'].'</td>
                                <td>'.$breed['Notes'].'</td>');
                                if(!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== "rancher"){
                                    print_r('
                                <td>
                                    <button>
                                        <a style="color:white;" href="http://localhost/ARRMS/ARRMS/ARRMS/admin/updateBreeding.php?id='.$breed['BreedingID'].'">Edit</a>
                                    </button>
                                    <button style="float:right;">
                                    <a style="color:white;" href="http://localhost/ARRMS/ARRMS/ARRMS/admin/delete.php?id='.$breed['BreedingID'].'&table=breeding">Delete</a>
                                    </button>
                                </td>');
                            }
                            print_r('</tr>');
                }?>
            </tbody>
        </table>
    </section>
    </fieldset>
    <br>

    <br>
    <br>
    <!--footer--->
    <footer>
        <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Records Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
                <a href="#">Home</a>
                <a href="#">About Us</a>
                <a href="#">Login</a>
                <a href="#">Registration</a>
                <a href="#">Contact Us</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
    <script>
        // Function to fetch breeding records from the server and populate the table
        function fetchBreedingRecords() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'breeding.php', true);
        xhr.onload = function() {
            if (this.status == 200) {
                var breedingRecords = JSON.parse(this.responseText);
                var tbody = document.querySelector('tbody');
                tbody.innerHTML = ''; // Clear existing table data
                breedingRecords.forEach(function(record) {
                    var tr = document.createElement('tr');
                    tr.innerHTML = '<td>' + record.BreedingID + '</td>' +
                                   '<td>' + record.Parent1ID + '</td>' +
                                   '<td>' + record.Parent2ID + '</td>' +
                                   '<td>' + record.DateOfBreeding + '</td>' +
                                   '<td>' + record.NumberOfOffspring + '</td>' +
                                   '<td>' + record.BreedingLocation + '</td>' +
                                   '<td>' + record.Notes + '</td>';
                    tbody.appendChild(tr);
                });
            }
        }
        xhr.send();
    }

    // Function to handle form submission
    document.getElementById('addBreedingRecordForm').addEventListener('submit', function(e) {
        e.preventDefault();
        var formData = new FormData(this);
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'breeding.php', true);
        xhr.onload = function() {
            if (this.status == 200) {
                fetchBreedingRecords(); // Refresh the breeding records table after adding a new record
                // Clear the form after submission if needed
                document.getElementById('addBreedingRecordForm').reset();
            }
        }
        xhr.send(formData);
    });

    // Fetch breeding records on page load
    fetchBreedingRecords();


    function goToDashboard() {
        // Redirect to the dashboard page
        window.location.href = 'dashboard.html';
    }
</script>
</body>

</html>