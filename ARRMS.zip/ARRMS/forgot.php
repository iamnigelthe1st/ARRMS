<?php
@session_start();
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "arrms"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $oldPassword = $_POST["old_password"];
    $newPassword = $_POST["new_password"];
    $confirmPassword = $_POST["confirm_password"];

    // Validate if new password is not the same as old password
    if ($newPassword == $oldPassword) {
        echo "<script>alert('New password should be different from the old password');</script>";
    } else {
        // Fetch user's hashed password from database
        $userId = $_SESSION["user_id"]; // Assuming you have stored user's ID in session
        $stmt = $conn->prepare("SELECT PasswordHash FROM Ranchers WHERE RancherID = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $storedPasswordHash = $row["PasswordHash"];

        // Verify old password
        if (password_verify($oldPassword, $storedPasswordHash)) {
            // Hash the new password
            $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
            
            // Update the password in the database
            $updateStmt = $conn->prepare("UPDATE Ranchers SET PasswordHash = ? WHERE RancherID = ?");
            $updateStmt->bind_param("si", $newPasswordHash, $userId);
            if ($updateStmt->execute()) {
                echo "<script>alert('Password updated successfully');</script>";
                header("Location: login.php");
                exit();
            } else {
                echo "<script>alert('Failed to update password');</script>";
            }
        } else {
            echo "<script>alert('Incorrect old password');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ARRMS</title>
    <!--bootstrap for layout-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha256-eZrrJcwDc/3uDhsdt61sL2oOBY362qM3lon1gyExkL0=" crossorigin="anonymous" />
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="./css/home.css">
    <!--script to verify postal address-->
<script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places"></script>
<style>
    /*--------this is for the registration tab---------*/
.container {
    max-width: 400px;
    background-color: #ffffff;
    border-radius: 10px;
    padding: 30px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    margin: 50px auto;
}

legend {
    font-size: 1.5em;
    font-weight: bold;
    margin-bottom: 20px;
    color: #333;
}

.form-group {
    margin-bottom: 20px;
}

label {
    font-weight: bold;
    color: #333;
}

textarea.form-control {
    resize: vertical;
}

.btn-primary,
.btn-secondary,
.btn-danger {
    width: 100%;
    margin-top: 10px;
}

.btn-primary:hover,
.btn-secondary:hover,
.btn-danger:hover {
    opacity: 0.8;
}

.btn-danger {
    background-color: #d9534f;
    border-color: #d9534f;
}

.btn-danger:hover {
    background-color: #c9302c;
    border-color: #ac2925;
}

/* Optional: Add media queries for responsiveness 
@media (max-width: 768px) {
    .container {
        width: 90%;
    }
} */
</style>
</head>
<body>
    
    <header>
    <nav class="navbar">
            <a href="#" class="logo">ARRMS:Forgot password</a>
            <ul class="nav-links">
                <li><a href="home.php">Home</a></li>
                <li><a href="login.php">Logout</a></li>
            </ul>
        </nav>
    </header>
<br>
<br>
<!-- Main content of your website goes here -->
<div class="container">
<fieldset>
    <form id="passwordForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <!-- Old Password -->
        <div class="form-group">
            <label for="old_password">Old Password</label>
            <input type="password" id="old_password" name="old_password" placeholder="Enter your old password" required>
        </div>
        <!-- New Password -->
        <div class="form-group">
            <label for="new_password">New Password</label>
            <input type="password" id="new_password" name="new_password" placeholder="Enter your new password" required>
        </div>
        <!-- Confirm New Password -->
        <div class="form-group">
            <label for="confirm_password">Confirm New Password</label>
            <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm your new password" required>
        </div>
        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary">Change Password</button>
    </form>
</fieldset>
</div>
<br>
<br>
    <footer>
    <div class="footer-content">
            <h3>ARRMS</h3>
            <p>Animal Ranching Recording Management System</p>
            <ul class="socials">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
            <div class="footer-links">
                <a href="#">Home</a>
                <a href="#">About Us</a>
                <a href="#">Login</a>
                <a href="#">Registration</a>
                <a href="#">Contact Us</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Copyright &copy; 2023 Designed by <span>Keegan Ibabu</span></p>
        </div>
    </footer>
    <script>
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("passwordForm").addEventListener("submit", function(event) {
        var oldPassword = document.getElementById("old_password").value;
        var newPassword = document.getElementById("new_password").value;
        var confirmPassword = document.getElementById("confirm_password").value;
        
        if (newPassword == oldPassword) {
            alert("New password should be different from the old password");
            event.preventDefault();
        } else if (newPassword != confirmPassword) {
            alert("New password and confirm password do not match");
            event.preventDefault();
        }
    });
});
</script>
</body>
</html>
